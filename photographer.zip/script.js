/* =====================================================
   MOBILE NAVIGATION
===================================================== */

const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

menuBtn.addEventListener("click", () => {

    nav.classList.toggle("active");

});


/* Close menu when a link is clicked */

const navLinks = document.querySelectorAll(".nav a");

navLinks.forEach(link => {

    link.addEventListener("click", () => {

        nav.classList.remove("active");

    });

});



/* =====================================================
   HEADER SCROLL EFFECT
===================================================== */

const header = document.getElementById("header");

window.addEventListener("scroll", () => {

    if (window.scrollY > 60) {

        header.style.background =
            "rgba(7,7,7,0.97)";

    } else {

        header.style.background =
            "rgba(11,11,11,0.75)";

    }

});



/* =====================================================
   CURRENT YEAR
===================================================== */

document.getElementById("year").textContent =
    new Date().getFullYear();



/* =====================================================
   CONTACT FORM → WHATSAPP
===================================================== */

const contactForm =
    document.getElementById("contactForm");


contactForm.addEventListener("submit", function(event) {

    event.preventDefault();


    const name =
        document.getElementById("name").value.trim();


    const phone =
        document.getElementById("phone").value.trim();


    const service =
        document.getElementById("service").value;


    const date =
        document.getElementById("date").value;


    const message =
        document.getElementById("message").value.trim();


    if (!name || !phone || !service || !message) {

        alert(
            "Please fill in all required fields."
        );

        return;

    }


    const whatsappNumber =
        "2347067844631";


    const whatsappMessage =

        "Hello Seyi Olayinka Photography,%0A%0A" +

        "I would like to make a booking/enquiry.%0A%0A" +

        "Name: " + encodeURIComponent(name) + "%0A" +

        "Phone: " + encodeURIComponent(phone) + "%0A" +

        "Service: " + encodeURIComponent(service) + "%0A" +

        "Date: " + encodeURIComponent(
            date || "Not specified"
        ) + "%0A" +

        "Message: " + encodeURIComponent(message);


    const whatsappURL =
        "https://wa.me/" +
        whatsappNumber +
        "?text=" +
        whatsappMessage;


    window.open(
        whatsappURL,
        "_blank"
    );

});



/* =====================================================
   IMAGE FALLBACK
===================================================== */

const images =
    document.querySelectorAll("img");


images.forEach(image => {

    image.addEventListener("error", () => {

        image.style.display = "none";

        image.parentElement.classList.add(
            "image-error"
        );

    });

});