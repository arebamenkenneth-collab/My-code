/* =========================================
   MADE BY YNK
   JAVASCRIPT
========================================= */


/* =========================================
   MOBILE MENU
========================================= */

const menuButton =
    document.getElementById("menuButton");

const navLinks =
    document.getElementById("navLinks");


menuButton.addEventListener("click", function () {

    navLinks.classList.toggle("active");

});


/* =========================================
   CLOSE MOBILE MENU AFTER CLICKING LINK
========================================= */

const navigationLinks =
    document.querySelectorAll(".nav-links a");


navigationLinks.forEach(function (link) {

    link.addEventListener("click", function () {

        navLinks.classList.remove("active");

    });

});


/* =========================================
   CONTACT FORM
========================================= */

const contactForm =
    document.getElementById("contactForm");


contactForm.addEventListener("submit", function (event) {

    event.preventDefault();


    const name =
        document.getElementById("name").value;


    const service =
        document.getElementById("service").value;


    if (name === "") {

        alert("Please enter your name.");

        return;

    }


    alert(
        "Thank you, " +
        name +
        "! Your " +
        (service || "fashion") +
        " enquiry has been received."
    );


    contactForm.reset();

});