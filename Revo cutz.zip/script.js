/* =========================
   ELEMENTS
========================= */

const header =
  document.getElementById("header");

const menuToggle =
  document.getElementById("menuToggle");

const navLinks =
  document.getElementById("navLinks");

const backTop =
  document.getElementById("backTop");



/* =========================
   MOBILE MENU
========================= */

menuToggle.addEventListener(
  "click",
  () => {

    const open =
      navLinks.classList.toggle("open");

    menuToggle.setAttribute(
      "aria-expanded",
      open
    );

  }
);



/* CLOSE MOBILE MENU
   WHEN LINK IS CLICKED
*/

document
  .querySelectorAll(".nav-links a")
  .forEach(link => {

    link.addEventListener(
      "click",
      () => {

        navLinks.classList.remove(
          "open"
        );

        menuToggle.setAttribute(
          "aria-expanded",
          "false"
        );

      }
    );

  });



/* =========================
   HEADER SCROLL EFFECT
========================= */

window.addEventListener(
  "scroll",
  () => {

    if (window.scrollY > 50) {

      header.classList.add(
        "scrolled"
      );

    } else {

      header.classList.remove(
        "scrolled"
      );

    }


    if (window.scrollY > 500) {

      backTop.classList.add(
        "show"
      );

    } else {

      backTop.classList.remove(
        "show"
      );

    }

  }
);



/* =========================
   BACK TO TOP
========================= */

backTop.addEventListener(
  "click",
  () => {

    window.scrollTo({

      top: 0,

      behavior: "smooth"

    });

  }
);



/* =========================
   SCROLL REVEAL
========================= */

const revealObserver =
  new IntersectionObserver(

    (entries) => {

      entries.forEach(
        entry => {

          if (
            entry.isIntersecting
          ) {

            entry.target.classList.add(
              "visible"
            );

            revealObserver.unobserve(
              entry.target
            );

          }

        }
      );

    },

    {
      threshold: 0.12
    }

  );



document
  .querySelectorAll(".reveal")
  .forEach(element => {

    revealObserver.observe(
      element
    );

  });



/* =========================
   GALLERY LIGHTBOX
========================= */

const lightbox =
  document.getElementById(
    "lightbox"
  );

const lightboxText =
  document.getElementById(
    "lightboxText"
  );

const lightboxClose =
  document.getElementById(
    "lightboxClose"
  );



document
  .querySelectorAll(".gallery-item")
  .forEach(item => {

    item.addEventListener(
      "click",
      () => {

        lightboxText.textContent =
          item.dataset.title ||
          "Revo Cutz Gallery";


        lightbox.classList.add(
          "open"
        );


        lightbox.setAttribute(
          "aria-hidden",
          "false"
        );


        document.body.classList.add(
          "no-scroll"
        );

      }
    );

  });



/* CLOSE LIGHTBOX */

function closeLightbox() {

  lightbox.classList.remove(
    "open"
  );


  lightbox.setAttribute(
    "aria-hidden",
    "true"
  );


  document.body.classList.remove(
    "no-scroll"
  );

}



lightboxClose.addEventListener(
  "click",
  closeLightbox
);



/* CLOSE WHEN CLICKING
   OUTSIDE CONTENT
*/

lightbox.addEventListener(
  "click",
  event => {

    if (
      event.target === lightbox
    ) {

      closeLightbox();

    }

  }
);



/* ESCAPE KEY */

document.addEventListener(
  "keydown",
  event => {

    if (
      event.key === "Escape"
    ) {

      closeLightbox();

    }

  }
);



/* =========================
   BOOKING FORM
========================= */

const bookingForm =
  document.getElementById(
    "bookingForm"
  );



bookingForm.addEventListener(
  "submit",
  function (event) {

    event.preventDefault();


    /* GET FORM VALUES */

    const name =
      document
        .getElementById("name")
        .value
        .trim();


    const phone =
      document
        .getElementById("phone")
        .value
        .trim();


    const date =
      document
        .getElementById("date")
        .value;


    const time =
      document
        .getElementById("time")
        .value;


    const service =
      document
        .getElementById("service")
        .value;


    const message =
      document
        .getElementById("message")
        .value
        .trim();



    /* CREATE WHATSAPP MESSAGE */

    const text =

`Hello Revo Cutz 👋

I'd like to book an appointment.

Name: ${name}
Phone: ${phone}
Service: ${service}
Preferred date: ${date}
Preferred time: ${time}
Message: ${message || "None"}

Thank you.`;



    /* WHATSAPP NUMBER */

    const whatsappNumber =
      "2347080316646";



    /* CREATE WHATSAPP URL */

    const whatsappURL =
      `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(text)}`;



    /* OPEN WHATSAPP */

    window.open(
      whatsappURL,
      "_blank"
    );

  }
);