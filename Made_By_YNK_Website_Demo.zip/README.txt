MADE BY YNK — WEBSITE CONCEPT

Open index.html in a browser to view the demo.

Notes:
- This is an unofficial concept/demo for outreach.
- Brand information was based only on the public Instagram profile shown by the user.
- Fashion images are demo/editorial images from Unsplash and should be replaced with the client's approved photos before publishing.
- The enquiry form is demo-only and can later be connected to WhatsApp, email, Flask, or another backend.
