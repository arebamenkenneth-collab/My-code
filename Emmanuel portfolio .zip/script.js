const menuToggle = document.querySelector(".menu-toggle");

const mobileMenu = document.querySelector(".mobile-menu");

menuToggle.addEventListener("click", function() {

    mobileMenu.classList.toggle("active");

    if (mobileMenu.classList.contains("active")) {

        menuToggle.textContent = "✕";

    } else {

        menuToggle.textContent = "☰";

    }

});

const menuLinks = document.querySelectorAll(".mobile-menu a");

menuLinks.forEach(function(link) {

    link.addEventListener("click", function() {

        mobileMenu.classList.remove("active");

        menuToggle.textContent = "☰";

    });

});

const faqQuestions = document.querySelectorAll(".faq-question");

faqQuestions.forEach(function(question) {

    question.addEventListener("click", function() {

        const answer = question.nextElementSibling;
        const icon = question.querySelector(".faq-icon");

        if (answer.style.display === "block") {

            answer.style.display = "none";
            icon.textContent = "+";

        } else {

            answer.style.display = "block";
            icon.textContent = "−";

        }

    });

});

const revealElements = document.querySelectorAll(
    ".about, .skills, .services, .work, .experience, .education, .certifications, .faq, .gallery, .contact, .footer"
);

function revealOnScroll() {

    revealElements.forEach(function(element) {

        const elementTop = element.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;

        if (elementTop < windowHeight - 100) {
            element.classList.add("active");
        }

    });

}

window.addEventListener("scroll", revealOnScroll);

revealOnScroll();

const backToTop = document.querySelector(".back-to-top");

window.addEventListener("scroll", function() {

    if (window.scrollY > 500) {
        backToTop.classList.add("show");
    } else {
        backToTop.classList.remove("show");
    }

});

backToTop.addEventListener("click", function() {

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

});



const featuredVideo = document.querySelector(".featured-video");

let videoWasPlaying = false;

const videoObserver = new IntersectionObserver(
    function(entries) {

        entries.forEach(function(entry) {

            if (entry.isIntersecting) {

                if (videoWasPlaying) {
                    featuredVideo.play();
                }

            } else {

                if (!featuredVideo.paused) {
                    videoWasPlaying = true;
                    featuredVideo.pause();
                }

            }

        });

    },
    {
        threshold: 0.5
    }
);

if (featuredVideo) {
    videoObserver.observe(featuredVideo);

    featuredVideo.addEventListener("pause", function() {

        if (featuredVideo.currentTime === 0) {
            videoWasPlaying = false;
        }

    });

    featuredVideo.addEventListener("play", function() {
        videoWasPlaying = true;
    });
}