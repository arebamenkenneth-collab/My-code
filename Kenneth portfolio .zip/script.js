/* Signal Noir standalone behavior: clear mobile navigation, honest interactions, restrained motion, and accessible state changes. */
(function () {
  const header = document.getElementById('site-header');
  const menuToggle = document.getElementById('menu-toggle');
  const mobileNav = document.getElementById('mobile-navigation');
  const menuIcon = menuToggle.querySelector('.menu-icon');
  const activeLabel = document.getElementById('active-label');

  function closeMenu() {
    mobileNav.classList.remove('is-open');
    menuToggle.classList.remove('is-open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation menu');
    menuIcon.textContent = '☰';
  }

  menuToggle.addEventListener('click', function () {
    const open = mobileNav.classList.toggle('is-open');
    menuToggle.classList.toggle('is-open', open);
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
    menuIcon.textContent = open ? '×' : '☰';
  });
  
  mobileNav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', closeMenu);
  });

  window.addEventListener('scroll', function () {
    header.classList.toggle('site-header--scrolled', window.scrollY > 28);
  }, { passive: true });

  const sections = Array.from(document.querySelectorAll('main section[id]'));
  const navLinks = Array.from(document.querySelectorAll('.desktop-nav a'));
  const observer = new IntersectionObserver(function (entries) {
    const visible = entries.filter(function (entry) { return entry.isIntersecting; }).sort(function (a, b) { return b.intersectionRatio - a.intersectionRatio; })[0];
    if (!visible) return;
    navLinks.forEach(function (link) { link.classList.toggle('is-active', link.getAttribute('href') === '#' + visible.target.id); });
    const current = navLinks.find(function (link) { return link.classList.contains('is-active'); });
    if (current) activeLabel.textContent = current.textContent.trim();
  }, { rootMargin: '-22% 0px -66% 0px', threshold: [0.1, 0.3, 0.6] });
  sections.forEach(function (section) { observer.observe(section); });

  const revealNodes = document.querySelectorAll('.reveal');
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    revealNodes.forEach(function (node) { node.classList.add('is-visible'); });
  } else {
    const revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) entry.target.classList.add('is-visible');
      });
    }, { threshold: 0.12 });
    revealNodes.forEach(function (node) { revealObserver.observe(node); });
  }

  document.querySelectorAll('.faq-item button').forEach(function (button) {
    button.addEventListener('click', function () {
      const item = button.closest('.faq-item');
      const open = item.classList.toggle('is-open');
      button.setAttribute('aria-expanded', String(open));
      document.querySelectorAll('.faq-item').forEach(function (other) {
        if (other !== item) {
          other.classList.remove('is-open');
          const otherButton = other.querySelector('button');
          if (otherButton) otherButton.setAttribute('aria-expanded', 'false');
        }
      });
    });
  });
  
  document.getElementById('contact-form').addEventListener('submit', function (event) {
    event.preventDefault();
    const button = event.currentTarget.querySelector('button[type="submit"]');
    button.textContent = 'Message captured ✓';
    button.setAttribute('aria-label', 'Message captured. This static form does not send email.');
    window.alert('Message captured for the next build. This static form is ready to connect to a Flask + SQLite backend.');
  });

  document.getElementById('files-button').addEventListener('click', function () {
    window.alert('Project file library is not connected yet. Add real project details to populate this workspace.');
  });
})();