const menuBtn = document.getElementById("menuBtn");
const navLinks = document.getElementById("navLinks");

// MOBILE MENU

menuBtn.addEventListener("click", () => {
navLinks.classList.toggle("show");
});

// CLOSE MENU WHEN LINK IS CLICKED

document.querySelectorAll(".nav-links a").forEach(link => {

link.addEventListener("click", () => {
navLinks.classList.remove("show");
});

});

// SCROLL REVEAL ANIMATION

const reveals = document.querySelectorAll(".reveal");

function revealOnScroll() {

reveals.forEach(element => {

const windowHeight = window.innerHeight;
const elementTop = element.getBoundingClientRect().top;

if (elementTop < windowHeight - 100) {
  element.classList.add("active");
}

});

}

window.addEventListener("scroll", revealOnScroll);

revealOnScroll();

// ORDER FORM

const orderForm = document.getElementById("orderForm");

orderForm.addEventListener("submit", function(event) {

event.preventDefault();

alert(
"Thank you for choosing Lola Cakes & Pastries! 🎂\n\n" +
"Your order request has been received."
);

orderForm.reset();

});