document.addEventListener("DOMContentLoaded", async () => {

    const newsList =
        document.getElementById("public-news-list");

    if (!newsList) return;


    const { data, error } =
        await supabaseClient
            .from("news")
            .select("*")
            .eq("is_active", true)
            .order("display_order", {
                ascending: true
            });


    if (error) {

        console.error(
            "Public news loading error:",
            error
        );

        return;
    }


    newsList.innerHTML = "";


    data.forEach((article) => {

        const newsCard =
            document.createElement("article");

        newsCard.className =
            "news-card";


        const date =
            new Date(article.created_at)
                .toLocaleDateString(
                    "en-US",
                    {
                        month: "long",
                        year: "numeric"
                    }
                );


        newsCard.innerHTML = `

            <div class="news-image">

                ${
                    article.image_url
                        ? `
                            <img
    src="${article.image_url}"
    alt="${article.title}"
    class="clickable-image"
    data-full-image="${article.image_url}"
>
                        `
                        : `
                            <div class="news-placeholder">
                                NEWS IMAGE
                            </div>
                        `
                }

            </div>


            <div class="news-content">

                <span class="news-category">
                    ${
                        article.category ||
                        "GENERAL"
                    }
                </span>


                <h3>
                    ${article.title}
                </h3>


                <p>
                    ${
                        article.excerpt ||
                        ""
                    }
                </p>


                <div class="news-footer">

                    <span>
                        ${date}
                    </span>

                    <a href="#contact">
                        Read More →
                    </a>

                </div>

            </div>

        `;


        newsList.appendChild(newsCard);

    });

});