document.addEventListener("DOMContentLoaded", () => {

const addTestimonialBtn =
    document.getElementById(
        "add-testimonial-btn"
    );

const addTestimonialForm =
    document.getElementById(
        "add-testimonial-form"
    );

const cancelTestimonialBtn =
    document.getElementById(
        "cancel-testimonial-btn"
    );

const saveTestimonialBtn =
    document.getElementById(
        "save-testimonial-btn"
    );


addTestimonialBtn.addEventListener(
    "click",
    () => {

        addTestimonialForm.style.display =
            "block";

        addTestimonialBtn.style.display =
            "none";

    }
);


cancelTestimonialBtn.addEventListener(
    "click",
    () => {

        addTestimonialForm.style.display =
            "none";

        addTestimonialBtn.style.display =
            "block";

    }
);


saveTestimonialBtn.addEventListener(
    "click",
    async () => {

        const name =
            document.getElementById(
                "testimonial-name"
            ).value.trim();

        const role =
            document.getElementById(
                "testimonial-role"
            ).value.trim();

        const company =
            document.getElementById(
                "testimonial-company"
            ).value.trim();

        const message =
            document.getElementById(
                "testimonial-message"
            ).value.trim();

        const imageInput =
            document.getElementById(
                "testimonial-image"
            );

        const imageFile =
            imageInput.files[0];

        const displayOrder =
            document.getElementById(
                "testimonial-order"
            ).value;


        if (!name || !message) {

            alert(
                "Please enter the client name and testimonial message."
            );

            return;
        }


        let imageUrl = "";


        /*
         * Upload client image
         */

        if (imageFile) {

            if (
                !imageFile.type.startsWith("image/")
            ) {

                alert(
                    "Please select a valid image file."
                );

                return;
            }


            const fileExtension =
                imageFile.name
                    .split(".")
                    .pop();


            const fileName =
                `testimonials/${Date.now()}-${Math.random()
                    .toString(36)
                    .substring(2)}.${fileExtension}`;


            const {
                error: uploadError
            } =
                await supabaseClient
                    .storage
                    .from("testimonial-photos")
                    .upload(
                        fileName,
                        imageFile
                    );


            if (uploadError) {

                console.error(
                    "Testimonial image upload error:",
                    uploadError
                );

                alert(
                    "Failed to upload client image: " +
                    uploadError.message
                );

                return;
            }


            const {
                data: publicUrlData
            } =
                supabaseClient
                    .storage
                    .from("testimonial-photos")
                    .getPublicUrl(
                        fileName
                    );


            imageUrl =
                publicUrlData.publicUrl;

        }


        /*
         * Save testimonial
         */

        const { error } =
            await supabaseClient
                .from("testimonials")
                .insert({

                    name: name,

                    role: role,

                    company: company,

                    message: message,

                    image_url: imageUrl,

                    is_active: true,

                    display_order:
                        Number(displayOrder) || 0

                });


        if (error) {

            console.error(
                "Insert testimonial error:",
                error
            );

            alert(
                "Failed to add testimonial: " +
                error.message
            );

            return;
        }


        alert(
            "Testimonial added successfully!"
        );


        document.getElementById(
            "testimonial-name"
        ).value = "";

        document.getElementById(
            "testimonial-role"
        ).value = "";

        document.getElementById(
            "testimonial-company"
        ).value = "";

        document.getElementById(
            "testimonial-message"
        ).value = "";

        document.getElementById(
            "testimonial-image"
        ).value = "";

        document.getElementById(
            "testimonial-order"
        ).value = "0";


        addTestimonialForm.style.display =
            "none";

        addTestimonialBtn.style.display =
            "block";


        loadTestimonials();

    }
);


async function loadTestimonials() {

    const { data, error } =
        await supabaseClient
            .from("testimonials")
            .select("*")
            .order("display_order", {
                ascending: true
            });


    if (error) {

        console.error(
            "Testimonials loading error:",
            error
        );

        return;
    }


    const testimonialsList =
        document.getElementById(
            "testimonials-list"
        );

    testimonialsList.innerHTML = "";


    data.forEach((testimonial) => {

        const testimonialItem =
            document.createElement("div");

        testimonialItem.className =
            "testimonial-item";


        testimonialItem.innerHTML = `

            <div class="testimonial-info">

                ${
                    testimonial.image_url
                        ? `
                            <img
                                src="${testimonial.image_url}"
                                alt="${testimonial.name}"
                                style="
                                    width:60px;
                                    height:60px;
                                    border-radius:50%;
                                    object-fit:cover;
                                    display:block;
                                    margin-bottom:12px;
                                "
                            >
                        `
                        : ""
                }

                <h3>
                    ${testimonial.name}
                </h3>

                <div class="testimonial-role">
                    ${testimonial.role || ""}
                </div>

                <div class="testimonial-company">
                    ${testimonial.company || ""}
                </div>

                <p class="testimonial-message">
                    ${testimonial.message}
                </p>

            </div>


            <div class="testimonial-actions">

                <button
                    class="edit-testimonial"
                >
                    Edit
                </button>

                <button
                    class="delete-testimonial"
                >
                    Delete
                </button>

            </div>

        `;


        testimonialsList.appendChild(
            testimonialItem
        );


        const editButton =
            testimonialItem.querySelector(
                ".edit-testimonial"
            );


        editButton.addEventListener(
            "click",
            async () => {

                const newName =
                    prompt(
                        "Enter client name:",
                        testimonial.name
                    );

                if (newName === null) {
                    return;
                }


                const newRole =
                    prompt(
                        "Enter role / position:",
                        testimonial.role || ""
                    );

                if (newRole === null) {
                    return;
                }


                const newCompany =
                    prompt(
                        "Enter company / organization:",
                        testimonial.company || ""
                    );

                if (newCompany === null) {
                    return;
                }


                const newMessage =
                    prompt(
                        "Enter testimonial message:",
                        testimonial.message
                    );

                if (newMessage === null) {
                    return;
                }


                const { error } =
                    await supabaseClient
                        .from("testimonials")
                        .update({

                            name: newName,

                            role: newRole,

                            company: newCompany,

                            message: newMessage

                        })
                        .eq(
                            "id",
                            testimonial.id
                        );


                if (error) {

                    console.error(
                        "Update testimonial error:",
                        error
                    );

                    alert(
                        "Failed to update testimonial: " +
                        error.message
                    );

                    return;
                }


                alert(
                    "Testimonial updated successfully!"
                );


                loadTestimonials();

            }
        );


        const deleteButton =
            testimonialItem.querySelector(
                ".delete-testimonial"
            );


        deleteButton.addEventListener(
            "click",
            async () => {

                const confirmed =
                    confirm(
                        `Are you sure you want to delete the testimonial from ${testimonial.name}?`
                    );


                if (!confirmed) {
                    return;
                }


                const { error } =
                    await supabaseClient
                        .from("testimonials")
                        .delete()
                        .eq(
                            "id",
                            testimonial.id
                        );


                if (error) {

                    console.error(
                        "Delete testimonial error:",
                        error
                    );

                    alert(
                        "Failed to delete testimonial: " +
                        error.message
                    );

                    return;
                }


                alert(
                    "Testimonial deleted successfully!"
                );


                loadTestimonials();

            }
        );

    });

}


loadTestimonials();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});