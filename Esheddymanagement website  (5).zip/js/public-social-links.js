function getSocialIcon(platform) {

    const icons = {
        Instagram: "fa-brands fa-instagram",
        Facebook: "fa-brands fa-facebook-f",
        LinkedIn: "fa-brands fa-linkedin-in",
        TikTok: "fa-brands fa-tiktok",
        X: "fa-brands fa-x-twitter",
        YouTube: "fa-brands fa-youtube",
        WhatsApp: "fa-brands fa-whatsapp"
    };

    return icons[platform] || "fa-solid fa-link";
}


async function loadPublicSocialLinks() {

    const socialLinksContainer =
        document.getElementById("public-social-links");

    if (!socialLinksContainer) {
        return;
    }

    const { data, error } = await supabaseClient
        .from("social_links")
        .select("*")
        .eq("is_active", true)
        .order("display_order", { ascending: true })
        .order("created_at", { ascending: false });

    if (error) {

        console.error(
            "Public social links error:",
            error
        );

        socialLinksContainer.innerHTML = `
            <div class="public-social-empty">
                Social links unavailable.
            </div>
        `;

        return;
    }

    socialLinksContainer.innerHTML = "";

    if (!data || data.length === 0) {

        socialLinksContainer.innerHTML = `
            <div class="public-social-empty">
                Follow us on social media.
            </div>
        `;

        return;
    }

    data.forEach((social) => {

        const link =
            document.createElement("a");

        link.className =
            "public-social-link";

        link.href = social.url;

        link.target = "_blank";

        link.rel =
            "noopener noreferrer";

        const iconClass =
            getSocialIcon(social.platform);

        link.innerHTML = `
            <span class="public-social-link-icon">
                <i class="${iconClass}"></i>
            </span>

            <span>
                ${social.platform}
            </span>
        `;

        socialLinksContainer.appendChild(link);

    });

}


document.addEventListener(
    "DOMContentLoaded",
    loadPublicSocialLinks
);