async function loadPublicAbout() {

const { data, error } = await supabaseClient
    .from("site_settings")
    .select("description, mission, vision")
    .eq("id", 1)
    .maybeSingle();


if (error) {

    console.error(
        "Public About error:",
        error
    );

    return;
}


if (!data) {
    return;
}


const description =
    document.getElementById(
        "public-about-description"
    );

const mission =
    document.getElementById(
        "public-about-mission"
    );

const vision =
    document.getElementById(
        "public-about-vision"
    );


if (description && data.description) {

    description.textContent =
        data.description;

}


if (mission && data.mission) {

    mission.textContent =
        data.mission;

}


if (vision && data.vision) {

    vision.textContent =
        data.vision;

}

}

document.addEventListener(
"DOMContentLoaded",
loadPublicAbout
);