const socialLinkForm = document.getElementById("social-link-form");
const socialLinksList = document.getElementById("social-links-list");


async function loadSocialLinks() {

    const { data, error } = await supabaseClient
        .from("social_links")
        .select("*")
        .order("display_order", { ascending: true })
        .order("created_at", { ascending: false });

    if (error) {

        console.error("Social links load error:", error);

        socialLinksList.innerHTML = `
            <div class="social-links-empty">
                Unable to load social links.
            </div>
        `;

        return;
    }


    socialLinksList.innerHTML = "";


    if (!data || data.length === 0) {

        socialLinksList.innerHTML = `
            <div class="social-links-empty">
                No social links added yet.
            </div>
        `;

        return;
    }


    data.forEach((social) => {

        const card = document.createElement("article");

        card.className = "social-link-admin-card";


        card.innerHTML = `

            <h3>
                ${social.platform}
            </h3>

            <a
                href="${social.url}"
                target="_blank"
                rel="noopener noreferrer"
                class="social-link-admin-url"
            >
                ${social.url}
            </a>

            <span class="social-link-admin-status">
                ${social.is_active ? "Active" : "Inactive"}
            </span>

            <div class="social-link-admin-actions">

                <button
                    type="button"
                    class="social-link-delete-btn"
                    data-id="${social.id}"
                >
                    Delete
                </button>

            </div>
        `;


        socialLinksList.appendChild(card);

    });


    document
        .querySelectorAll(".social-link-delete-btn")
        .forEach((button) => {

            button.addEventListener("click", async () => {

                const id = button.dataset.id;

                const confirmed = confirm(
                    "Delete this social link?"
                );

                if (!confirmed) return;


                const { error } = await supabaseClient
                    .from("social_links")
                    .delete()
                    .eq("id", id);


                if (error) {

                    console.error(
                        "Social link delete error:",
                        error
                    );

                    alert(
                        "Unable to delete social link."
                    );

                    return;
                }


                loadSocialLinks();

            });

        });

}


socialLinkForm.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();


        const button =
            document.getElementById("save-social-btn");

        button.disabled = true;
        button.textContent = "Adding...";


        const platform =
            document.getElementById("social-platform")
                .value;

        const url =
            document.getElementById("social-url")
                .value
                .trim();

        const displayOrder =
            Number(
                document.getElementById("social-order")
                    .value
            );

        const isActive =
            document.getElementById("social-active")
                .value === "true";


        const { error } = await supabaseClient
            .from("social_links")
            .insert([
                {
                    platform: platform,
                    url: url,
                    display_order: displayOrder,
                    is_active: isActive
                }
            ]);


        if (error) {

            console.error(
                "Social link insert error:",
                error
            );

            alert(
                "Unable to add social link."
            );

            button.disabled = false;
            button.textContent = "Add Social Link";

            return;
        }


        alert(
            "Social link added successfully."
        );


        socialLinkForm.reset();

        document.getElementById("social-order")
            .value = 0;

        document.getElementById("social-active")
            .value = "true";


        button.disabled = false;
        button.textContent = "Add Social Link";


        loadSocialLinks();

    }
);


loadSocialLinks();


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});