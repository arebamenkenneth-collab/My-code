document.addEventListener("DOMContentLoaded", async () => {

    const {
        data: { user }
    } = await supabaseClient.auth.getUser();


    if (!user) {

        window.location.href = "/admin/login.html";

        return;
    }


    // =========================
    // LOGOUT
    // =========================

    const logoutButton =
        document.getElementById("logout-btn");


    if (logoutButton) {

        logoutButton.addEventListener("click", async () => {

            logoutButton.disabled = true;

            logoutButton.textContent =
                "Logging out...";


            const { error } =
                await supabaseClient.auth.signOut();


            if (error) {

                console.error(
                    "Logout error:",
                    error
                );


                alert(
                    "Failed to log out. Please try again."
                );


                logoutButton.disabled = false;

                logoutButton.textContent =
                    "Logout";

                return;
            }


            sessionStorage.removeItem(
                "esheddy_admin_last_activity"
            );


            window.location.href =
                "/admin/login.html";

        });

    }


    // =========================
    // 40-SECOND INACTIVITY LOCK
    // =========================

    const INACTIVITY_LIMIT = 40 * 1000;

    let lockTimer;


    function updateActivity() {

        if (
            document.body.classList.contains(
                "admin-locked"
            )
        ) {
            return;
        }


        sessionStorage.setItem(
            "esheddy_admin_last_activity",
            Date.now().toString()
        );


        resetLockTimer();

    }


    function resetLockTimer() {

        clearTimeout(lockTimer);


        lockTimer = setTimeout(() => {

            lockAdminPage();

        }, INACTIVITY_LIMIT);

    }


    function lockAdminPage() {

        if (
            document.body.classList.contains(
                "admin-locked"
            )
        ) {
            return;
        }


        document.body.classList.add(
            "admin-locked"
        );


        clearTimeout(lockTimer);


        showLockScreen();

    }


    function showLockScreen() {

        const overlay =
            document.createElement("div");


        overlay.id =
            "admin-lock-screen";


        overlay.innerHTML = `

            <div class="admin-lock-card">

                <h2>Admin Locked</h2>

                <p>
                    Your session was locked because
                    there was no activity for 40 seconds.
                </p>

                <form id="admin-unlock-form">

                    <label for="admin-unlock-password">
                        Password
                    </label>

                    <input
                        type="password"
                        id="admin-unlock-password"
                        placeholder="Enter your password"
                        required
                        autocomplete="current-password"
                    >

                    <button
                        type="submit"
                        id="admin-unlock-btn"
                    >
                        Unlock
                    </button>

                    <p id="admin-unlock-message"></p>

                </form>

            </div>

        `;


        document.body.appendChild(overlay);


        const form =
            document.getElementById(
                "admin-unlock-form"
            );


        const passwordInput =
            document.getElementById(
                "admin-unlock-password"
            );


        const unlockButton =
            document.getElementById(
                "admin-unlock-btn"
            );


        const message =
            document.getElementById(
                "admin-unlock-message"
            );


        passwordInput.focus();


        form.addEventListener(
            "submit",
            async (event) => {

                event.preventDefault();


                const password =
                    passwordInput.value;


                unlockButton.disabled =
                    true;

                unlockButton.textContent =
                    "Unlocking...";

                message.textContent = "";


                const {
                    error
                } =
                    await supabaseClient.auth.signInWithPassword({

                        email: user.email,

                        password:
                            password

                    });


                if (error) {

                    console.error(
                        "Unlock error:",
                        error
                    );


                    message.textContent =
                        "Incorrect password. Please try again.";

                    passwordInput.value = "";

                    passwordInput.focus();

                    unlockButton.disabled =
                        false;

                    unlockButton.textContent =
                        "Unlock";

                    return;

                }


                overlay.remove();


                document.body.classList.remove(
                    "admin-locked"
                );


                sessionStorage.setItem(
                    "esheddy_admin_last_activity",
                    Date.now().toString()
                );


                resetLockTimer();

            }

        );

    }


    // =========================
    // ACTIVITY DETECTION
    // =========================

    [

        "mousemove",
        "keydown",
        "scroll",
        "touchstart",
        "touchmove"
    ].forEach((eventName) => {

        document.addEventListener(
            eventName,
            updateActivity,
            { passive: true }
        );

    });


    // =========================
    // INITIAL TIMER
    // =========================

    const lastActivity =
        sessionStorage.getItem(
            "esheddy_admin_last_activity"
        );


    if (lastActivity) {

        const elapsed =
            Date.now() - Number(lastActivity);


        if (elapsed >= INACTIVITY_LIMIT) {

            lockAdminPage();

        } else {

            lockTimer =
                setTimeout(
                    lockAdminPage,
                    INACTIVITY_LIMIT - elapsed
                );

        }

    } else {

        updateActivity();

    }

});