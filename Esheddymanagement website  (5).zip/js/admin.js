async function loadServicesCount() {

    const { count, error } =
        await supabaseClient
            .from("services")
            .select("*", {
                count: "exact",
                head: true
            });

    if (error) {
        console.error(
            "Services error:",
            error
        );
        return;
    }

    document.getElementById(
        "services-count"
    ).textContent = count;

}

loadServicesCount();



async function loadTalentsCount() {

    const { count, error } =
        await supabaseClient
            .from("talents")
            .select("*", {
                count: "exact",
                head: true
            });

    if (error) {
        console.error(
            "Talents error:",
            error
        );
        return;
    }

    document.getElementById(
        "talents-count"
    ).textContent = count;

}

loadTalentsCount();



async function loadProjectsCount() {

    const { count, error } =
        await supabaseClient
            .from("projects")
            .select("*", {
                count: "exact",
                head: true
            });

    if (error) {
        console.error(
            "Projects error:",
            error
        );
        return;
    }

    document.getElementById(
        "projects-count"
    ).textContent = count;

}

loadProjectsCount();



async function loadBookingsCount() {

    const { count, error } =
        await supabaseClient
            .from("bookings")
            .select("*", {
                count: "exact",
                head: true
            });

    if (error) {
        console.error(
            "Bookings error:",
            error
        );
        return;
    }

    document.getElementById(
        "bookings-count"
    ).textContent = count;

}

loadBookingsCount();



/* =========================
   MESSAGES COUNT
========================= */

async function loadMessagesCount() {

    const { count, error } =
        await supabaseClient
            .from("messages")
            .select("*", {
                count: "exact",
                head: true
            });

    if (error) {
        console.error(
            "Messages error:",
            error
        );
        return;
    }

    document.getElementById(
        "messages-count"
    ).textContent = count;

}

loadMessagesCount();



/* =========================
   NEWS COUNT
========================= */

async function loadNewsCount() {

    const { count, error } =
        await supabaseClient
            .from("news")
            .select("*", {
                count: "exact",
                head: true
            });

    if (error) {
        console.error(
            "News error:",
            error
        );
        return;
    }

    document.getElementById(
        "news-count"
    ).textContent = count;

}

loadNewsCount();



window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});
