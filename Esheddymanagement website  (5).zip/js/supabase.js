const SUPABASE_URL = "https://mdxatoctnytfdvmjlzpn.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_U1QUkp0WZJyNP8NZ1x33vA_EupKJqaf";

const supabaseClient = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_PUBLISHABLE_KEY
);