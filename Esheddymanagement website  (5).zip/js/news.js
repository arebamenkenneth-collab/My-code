document.addEventListener("DOMContentLoaded", () => {

const addNewsBtn =
    document.getElementById("add-news-btn");

const addNewsForm =
    document.getElementById("add-news-form");

const cancelNewsBtn =
    document.getElementById("cancel-news-btn");

const saveNewsBtn =
    document.getElementById("save-news-btn");


addNewsBtn.addEventListener("click", () => {

    addNewsForm.style.display = "block";
    addNewsBtn.style.display = "none";

});


cancelNewsBtn.addEventListener("click", () => {

    addNewsForm.style.display = "none";
    addNewsBtn.style.display = "block";

});


saveNewsBtn.addEventListener("click", async () => {

    const title =
        document.getElementById("news-title")
            .value.trim();

    const excerpt =
        document.getElementById("news-excerpt")
            .value.trim();

    const content =
        document.getElementById("news-content")
            .value.trim();

    const category =
        document.getElementById("news-category")
            .value.trim();

    const imageInput =
        document.getElementById("news-image");

    const imageFile =
        imageInput.files[0];

    const displayOrder =
        document.getElementById("news-order")
            .value;


    if (!title || !content) {

        alert(
            "Please enter a news title and content."
        );

        return;
    }


    let imageUrl = "";


    /*
     * Upload news image
     */

    if (imageFile) {

        if (!imageFile.type.startsWith("image/")) {

            alert(
                "Please select a valid image file."
            );

            return;
        }


        const fileExtension =
            imageFile.name
                .split(".")
                .pop();


        const fileName =
            `news/${Date.now()}-${Math.random()
                .toString(36)
                .substring(2)}.${fileExtension}`;


        const {
            error: uploadError
        } =
            await supabaseClient
                .storage
                .from("news-images")
                .upload(
                    fileName,
                    imageFile
                );


        if (uploadError) {

            console.error(
                "News image upload error:",
                uploadError
            );

            alert(
                "Failed to upload news image: " +
                uploadError.message
            );

            return;
        }


        const {
            data: publicUrlData
        } =
            supabaseClient
                .storage
                .from("news-images")
                .getPublicUrl(
                    fileName
                );


        imageUrl =
            publicUrlData.publicUrl;

    }


    /*
     * Save news
     */

    const { error } =
        await supabaseClient
            .from("news")
            .insert({

                title: title,

                excerpt: excerpt,

                content: content,

                category: category,

                image_url: imageUrl,

                is_active: true,

                display_order:
                    Number(displayOrder) || 0

            });


    if (error) {

        console.error(
            "Insert news error:",
            error
        );

        alert(
            "Failed to add news: " +
            error.message
        );

        return;
    }


    alert(
        "News added successfully!"
    );


    document.getElementById(
        "news-title"
    ).value = "";

    document.getElementById(
        "news-excerpt"
    ).value = "";

    document.getElementById(
        "news-content"
    ).value = "";

    document.getElementById(
        "news-category"
    ).value = "";

    document.getElementById(
        "news-image"
    ).value = "";

    document.getElementById(
        "news-order"
    ).value = "0";


    addNewsForm.style.display = "none";
    addNewsBtn.style.display = "block";


    loadNews();

});


async function loadNews() {

    const { data, error } =
        await supabaseClient
            .from("news")
            .select("*")
            .order("display_order", {
                ascending: true
            });


    if (error) {

        console.error(
            "News loading error:",
            error
        );

        return;
    }


    const newsList =
        document.getElementById("news-list");

    newsList.innerHTML = "";


    data.forEach((article) => {

        const newsItem =
            document.createElement("div");

        newsItem.className =
            "news-item";


        newsItem.innerHTML = `

            <div class="news-info">

                ${
                    article.image_url
                        ? `
                            <img
                                src="${article.image_url}"
                                alt="${article.title}"
                                style="
                                    width:100px;
                                    height:70px;
                                    object-fit:cover;
                                    border-radius:8px;
                                    display:block;
                                    margin-bottom:12px;
                                "
                            >
                        `
                        : ""
                }

                <h3>
                    ${article.title}
                </h3>

                <div class="news-category">
                    ${article.category || "General"}
                </div>

                <p>
                    ${article.excerpt || ""}
                </p>

            </div>


            <div class="news-actions">

                <button
                    class="edit-news"
                >
                    Edit
                </button>

                <button
                    class="delete-news"
                >
                    Delete
                </button>

            </div>

        `;


        newsList.appendChild(newsItem);


        const editButton =
            newsItem.querySelector(
                ".edit-news"
            );


        editButton.addEventListener(
            "click",
            async () => {

                const newTitle =
                    prompt(
                        "Enter news title:",
                        article.title
                    );

                if (newTitle === null) {
                    return;
                }


                const newExcerpt =
                    prompt(
                        "Enter news excerpt:",
                        article.excerpt || ""
                    );

                if (newExcerpt === null) {
                    return;
                }


                const newContent =
                    prompt(
                        "Enter news content:",
                        article.content || ""
                    );

                if (newContent === null) {
                    return;
                }


                const newCategory =
                    prompt(
                        "Enter news category:",
                        article.category || ""
                    );

                if (newCategory === null) {
                    return;
                }


                const { error } =
                    await supabaseClient
                        .from("news")
                        .update({

                            title: newTitle,

                            excerpt: newExcerpt,

                            content: newContent,

                            category: newCategory

                        })
                        .eq(
                            "id",
                            article.id
                        );


                if (error) {

                    console.error(
                        "Update news error:",
                        error
                    );

                    alert(
                        "Failed to update news: " +
                        error.message
                    );

                    return;
                }


                alert(
                    "News updated successfully!"
                );


                loadNews();

            }
        );


        const deleteButton =
            newsItem.querySelector(
                ".delete-news"
            );


        deleteButton.addEventListener(
            "click",
            async () => {

                const confirmed =
                    confirm(
                        `Are you sure you want to delete "${article.title}"?`
                    );


                if (!confirmed) {
                    return;
                }


                const { error } =
                    await supabaseClient
                        .from("news")
                        .delete()
                        .eq(
                            "id",
                            article.id
                        );


                if (error) {

                    console.error(
                        "Delete news error:",
                        error
                    );

                    alert(
                        "Failed to delete news: " +
                        error.message
                    );

                    return;
                }


                alert(
                    "News deleted successfully!"
                );


                loadNews();

            }
        );

    });

}


loadNews();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});