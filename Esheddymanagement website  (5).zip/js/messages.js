document.addEventListener(
    "DOMContentLoaded",
    async () => {

        const messagesList =
            document.getElementById(
                "messages-list"
            );

        if (!messagesList) return;


        messagesList.innerHTML =
            "<p>Loading messages...</p>";


        const { data, error } =
            await supabaseClient
                .from("messages")
                .select("*")
                .order(
                    "created_at",
                    {
                        ascending: false
                    }
                );


        if (error) {

            console.error(
                "Messages loading error:",
                error
            );

            messagesList.innerHTML = `
                <p>
                    Unable to load messages.
                </p>
            `;

            return;
        }


        if (!data || data.length === 0) {

            messagesList.innerHTML = `
                <p>
                    No messages yet.
                </p>
            `;

            return;
        }


        messagesList.innerHTML = "";


        data.forEach((message) => {

            const card =
                document.createElement(
                    "article"
                );

            card.className =
                "message-admin-card";


            card.innerHTML = `

                <div class="message-admin-header">

                    <div>

                        <h3>
                            ${message.name}
                        </h3>

                        <span>
                            ${new Date(
                                message.created_at
                            ).toLocaleString()}
                        </span>

                    </div>


                    <select
                        class="message-status-select"
                        data-id="${message.id}"
                    >

                        <option value="unread"
                            ${message.status === "unread" ? "selected" : ""}>
                            Unread
                        </option>

                        <option value="read"
                            ${message.status === "read" ? "selected" : ""}>
                            Read
                        </option>

                        <option value="replied"
                            ${message.status === "replied" ? "selected" : ""}>
                            Replied
                        </option>

                        <option value="archived"
                            ${message.status === "archived" ? "selected" : ""}>
                            Archived
                        </option>

                    </select>

                </div>


                <div class="message-admin-details">

                    <div class="message-detail">

                        <strong>
                            Email
                        </strong>

                        <span>
                            ${message.email}
                        </span>

                    </div>


                    <div class="message-detail">

                        <strong>
                            Phone / WhatsApp
                        </strong>

                        <span>
                            ${message.phone || "Not provided"}
                        </span>

                    </div>


                    <div class="message-detail">

                        <strong>
                            Company / Organization
                        </strong>

                        <span>
                            ${message.company || "Not provided"}
                        </span>

                    </div>


                    <div class="message-detail">

                        <strong>
                            Inquiry Type
                        </strong>

                        <span>
                            ${message.inquiry_type || "Not specified"}
                        </span>

                    </div>

                </div>


                <div class="message-admin-content">

                    <strong>
                        Message
                    </strong>

                    <p>
                        ${message.message}
                    </p>

                </div>


                <div class="message-admin-actions">

                    <button
                        type="button"
                        class="delete-message"
                        data-id="${message.id}"
                    >
                        Delete Message
                    </button>

                </div>

            `;


            messagesList.appendChild(
                card
            );

        });


        /*
            MESSAGE STATUS MANAGEMENT
        */

        const statusSelectors =
            document.querySelectorAll(
                ".message-status-select"
            );


        statusSelectors.forEach((select) => {

            select.addEventListener(
                "change",
                async () => {

                    const messageId =
                        select.dataset.id;

                    const newStatus =
                        select.value;


                    const { error } =
                        await supabaseClient
                            .from("messages")
                            .update({
                                status: newStatus
                            })
                            .eq(
                                "id",
                                messageId
                            );


                    if (error) {

                        console.error(
                            "Message status update error:",
                            error
                        );

                        alert(
                            "Update failed: " +
                            error.message
                        );

                        return;
                    }


                    console.log(
                        "Message status updated:",
                        newStatus
                    );

                }
            );

        });


        /*
            DELETE MESSAGE
        */

        const deleteButtons =
            document.querySelectorAll(
                ".delete-message"
            );


        deleteButtons.forEach((button) => {

            button.addEventListener(
                "click",
                async () => {

                    const messageId =
                        button.dataset.id;


                    const confirmed =
                        confirm(
                            "Are you sure you want to delete this message?"
                        );


                    if (!confirmed) return;


                    const { error } =
                        await supabaseClient
                            .from("messages")
                            .delete()
                            .eq(
                                "id",
                                messageId
                            );


                    if (error) {

                        console.error(
                            "Message delete error:",
                            error
                        );

                        alert(
                            "Delete failed: " +
                            error.message
                        );

                        return;
                    }


                    const messageCard =
                        button.closest(
                            ".message-admin-card"
                        );


                    if (messageCard) {

                        messageCard.remove();

                    }

                }
            );

        });

    }
);


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});