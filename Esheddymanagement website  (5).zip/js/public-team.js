document.addEventListener("DOMContentLoaded", async () => {

    const teamList =
        document.getElementById("public-team-list");

    if (!teamList) {
        return;
    }


    const { data, error } =
        await supabaseClient
            .from("team_members")
            .select("*")
            .eq("is_active", true)
            .order("display_order", {
                ascending: true
            });


    if (error) {

        console.error(
            "Public team loading error:",
            error
        );

        return;
    }


    teamList.innerHTML = "";


    data.forEach((member) => {

        const teamCard =
            document.createElement("article");

        teamCard.className =
            "team-card";


        teamCard.innerHTML = `

            <div class="team-image">

                ${
                    member.image_url

                    ? `
                        <img
                            src="${member.image_url}"
                            alt="${member.name}"
                        >
                    `

                    : `
                        <div class="team-placeholder">
                            PHOTO
                        </div>
                    `
                }

            </div>


            <div class="team-content">

                <h3>
                    ${member.name}
                </h3>


                <span class="team-position">
                    ${member.position}
                </span>


                <p>
                    ${member.bio || ""}
                </p>

            </div>

        `;


        teamList.appendChild(teamCard);

    });

});