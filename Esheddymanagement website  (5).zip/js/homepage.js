document.addEventListener("DOMContentLoaded", () => {

    const heroTitle =
        document.getElementById("hero-title");

    const heroDescription =
        document.getElementById("hero-description");

    const saveHomepageBtn =
        document.getElementById("save-homepage-btn");


    // LOAD HOMEPAGE SETTINGS

    async function loadHomepage() {

        const { data, error } = await supabaseClient
            .from("site_settings")
            .select(
                "hero_title, hero_description"
            )
            .limit(1)
            .maybeSingle();


        if (error) {

            console.error(
                "Homepage settings error:",
                error
            );

            alert(
                "Failed to load homepage settings: " +
                error.message
            );

            return;

        }


        console.log(
            "Homepage settings data:",
            data
        );


        if (!data) {

            console.log(
                "No homepage settings found."
            );

            return;

        }


        heroTitle.value =
            data.hero_title || "";


        heroDescription.value =
            data.hero_description || "";

    }


    // SAVE HOMEPAGE SETTINGS

    saveHomepageBtn.addEventListener(
        "click",
        async () => {

            const title =
                heroTitle.value.trim();


            const description =
                heroDescription.value.trim();


            if (!title || !description) {

                alert(
                    "Please enter the hero title and description."
                );

                return;

            }


            // CHECK EXISTING SETTINGS

            const {
                data: existingSettings,
                error: fetchError
            } = await supabaseClient
                .from("site_settings")
                .select("id")
                .limit(1)
                .maybeSingle();


            if (fetchError) {

                console.error(
                    "Settings lookup error:",
                    fetchError
                );

                alert(
                    "Failed to check homepage settings: " +
                    fetchError.message
                );

                return;

            }


            let error;


            // UPDATE EXISTING SETTINGS

            if (existingSettings) {

                const result =
                    await supabaseClient
                        .from("site_settings")
                        .update({
                            hero_title: title,
                            hero_description: description
                        })
                        .eq(
                            "id",
                            existingSettings.id
                        );


                error =
                    result.error;

            }


            // CREATE SETTINGS IF NONE EXIST

            else {

                const result =
                    await supabaseClient
                        .from("site_settings")
                        .insert({
                            hero_title: title,
                            hero_description: description
                        });


                error =
                    result.error;

            }


            // HANDLE SAVE ERROR

            if (error) {

                console.error(
                    "Save homepage error:",
                    error
                );

                alert(
                    "Failed to save homepage: " +
                    error.message
                );

                return;

            }


            alert(
                "Homepage updated successfully!"
            );


            // RELOAD SAVED INFORMATION

            loadHomepage();

        }

    );


    // INITIAL LOAD

    loadHomepage();

});

window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});