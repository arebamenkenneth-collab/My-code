document.addEventListener("DOMContentLoaded", async () => {

    const testimonialsList =
        document.getElementById(
            "public-testimonials-list"
        );

    if (!testimonialsList) return;


    const { data, error } =
        await supabaseClient
            .from("testimonials")
            .select("*")
            .eq("is_active", true)
            .order("display_order", {
                ascending: true
            });


    if (error) {

        console.error(
            "Public testimonials loading error:",
            error
        );

        return;
    }


    testimonialsList.innerHTML = "";


    data.forEach((testimonial) => {

        const testimonialCard =
            document.createElement("article");

        testimonialCard.className =
            "testimonial-card";


        const authorDetails =
            [
                testimonial.role,
                testimonial.company
            ]
            .filter(Boolean)
            .join(" • ");


        testimonialCard.innerHTML = `

            <div class="testimonial-quote">
                “
            </div>


            <p class="testimonial-text">
                ${testimonial.message}
            </p>


            <div class="testimonial-author">

                <div class="testimonial-avatar">

                    ${
                        testimonial.image_url
                            ? `<img
                                src="${testimonial.image_url}"
                                alt="${testimonial.name}"
                            >`
                            : `<span>PHOTO</span>`
                    }

                </div>


                <div>

                    <h3>
                        ${testimonial.name}
                    </h3>

                    <span>
                        ${authorDetails}
                    </span>

                </div>

            </div>

        `;


        testimonialsList.appendChild(
            testimonialCard
        );

    });

});