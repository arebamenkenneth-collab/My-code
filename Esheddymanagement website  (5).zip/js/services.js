document.addEventListener("DOMContentLoaded", () => {

    const addServiceBtn = document.getElementById("add-service-btn");
    const addServiceForm = document.getElementById("add-service-form");
    const cancelServiceBtn = document.getElementById("cancel-service-btn");

    addServiceBtn.addEventListener("click", () => {
        addServiceForm.style.display = "block";
    });

    cancelServiceBtn.addEventListener("click", () => {
        addServiceForm.style.display = "none";
    });
    
    const saveServiceBtn = document.getElementById("save-service-btn");

saveServiceBtn.addEventListener("click", async () => {

    const title = document.getElementById("service-title").value.trim();
    const description = document.getElementById("service-description").value.trim();
    const displayOrder = document.getElementById("service-order").value;

    if (!title || !description) {
        alert("Please enter the service title and description.");
        return;
    }

    const { error } = await supabaseClient
        .from("services")
        .insert({
            title: title,
            description: description,
            display_order: Number(displayOrder) || 0,
            is_active: true
        });

    if (error) {
        console.error("Insert error:", error);
        alert("Failed to add service.");
        return;
    }

    alert("Service added successfully!");

    document.getElementById("service-title").value = "";
    document.getElementById("service-description").value = "";
    document.getElementById("service-order").value = "0";

    addServiceForm.style.display = "none";

    loadServices();
});
});

async function loadServices() {
    const { data, error } = await supabaseClient
        .from("services")
        .select("*")
        .order("display_order", { ascending: true });

    if (error) {
        console.error("Services error:", error);
        return;
    }

    const servicesList = document.getElementById("services-list");

    servicesList.innerHTML = "";

    data.forEach((service) => {
        const serviceItem = document.createElement("div");

        serviceItem.innerHTML = `
            <div>
                <h3>${service.title}</h3>
                <p>${service.description}</p>
            </div>

            <div class="service-actions">
                <button class="edit-service">Edit</button>
                <button class="delete-service">Delete</button>
            </div>
        `;

        servicesList.appendChild(serviceItem);

        const editButton = serviceItem.querySelector(".edit-service");

        editButton.addEventListener("click", async () => {
            const newTitle = prompt(
                "Enter new service title:",
                service.title
            );

            if (newTitle === null) {
                return;
            }

            const newDescription = prompt(
                "Enter new service description:",
                service.description
            );

            if (newDescription === null) {
                return;
            }

            const { error } = await supabaseClient
                .from("services")
                .update({
                    title: newTitle,
                    description: newDescription
                })
                .eq("id", service.id);

            if (error) {
                console.error("Update error:", error);
                alert("Failed to update service.");
                return;
            }

            alert("Service updated successfully!");

            loadServices();
        });

        const deleteButton = serviceItem.querySelector(".delete-service");

        deleteButton.addEventListener("click", async () => {
            const confirmed = confirm(
                `Are you sure you want to delete "${service.title}"?`
            );

            if (!confirmed) {
                return;
            }

            const { error } = await supabaseClient
                .from("services")
                .delete()
                .eq("id", service.id);

            if (error) {
                console.error("Delete error:", error);
                alert("Failed to delete service.");
                return;
            }

            alert("Service deleted successfully!");

            loadServices();
        });
    });
}

loadServices();

window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});