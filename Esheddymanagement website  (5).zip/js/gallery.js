const galleryForm = document.getElementById("gallery-form");
const galleryList = document.getElementById("gallery-list");
const saveGalleryBtn = document.getElementById("save-gallery-btn");

// =========================
// LOAD GALLERY IMAGES
// =========================

async function loadGalleryImages() {

if (!galleryList) return;

const { data, error } = await supabaseClient
    .from("gallery")
    .select("*")
    .order("display_order", { ascending: true })
    .order("created_at", { ascending: false });

if (error) {

    console.error(
        "Gallery load error:",
        error
    );

    galleryList.innerHTML =
        "<p>Unable to load gallery images.</p>";

    return;
}

galleryList.innerHTML = "";

if (!data || data.length === 0) {

    galleryList.innerHTML =
        "<p>No gallery images yet.</p>";

    return;
}

data.forEach((image) => {

    const card =
        document.createElement("div");

    card.className =
        "gallery-admin-card";


    card.innerHTML = `

        <div class="gallery-admin-image">

            <img
                src="${image.image_url}"
                alt="${image.title}"
            >

        </div>


        <div class="gallery-admin-content">

            <h3>
                ${image.title}
            </h3>


            ${
                image.category
                    ? `
                        <span class="gallery-admin-category">
                            ${image.category}
                        </span>
                    `
                    : ""
            }


            ${
                image.description
                    ? `
                        <p>
                            ${image.description}
                        </p>
                    `
                    : ""
            }


            <div class="gallery-admin-actions">

                <button
                    class="gallery-delete-btn"
                    onclick="deleteGalleryImage(${image.id})"
                >
                    Delete
                </button>

            </div>

        </div>

    `;

    galleryList.appendChild(card);

});

}

// =========================
// ADD GALLERY IMAGE
// =========================

if (galleryForm) {

galleryForm.addEventListener(
    "submit",
    async (event) => {

        event.preventDefault();


        const title =
            document
                .getElementById("gallery-title")
                .value
                .trim();


        const description =
            document
                .getElementById("gallery-description")
                .value
                .trim();


        const category =
            document
                .getElementById("gallery-category")
                .value
                .trim();


        const imageInput =
            document.getElementById(
                "gallery-image"
            );


        const displayOrder =
            Number(
                document
                    .getElementById(
                        "gallery-order"
                    )
                    .value
            );


        const imageFile =
            imageInput.files[0];


        if (!title || !imageFile) {

            alert(
                "Please enter a title and select an image."
            );

            return;
        }


        saveGalleryBtn.disabled = true;

        saveGalleryBtn.textContent =
            "Uploading...";


        try {

            // =========================
            // CREATE UNIQUE FILE NAME
            // =========================

            const fileExtension =
                imageFile.name
                    .split(".")
                    .pop();


            const fileName =
                `gallery/${Date.now()}-${Math.random()
                    .toString(36)
                    .substring(2, 8)}.${fileExtension}`;


            // =========================
            // UPLOAD IMAGE
            // =========================

            const {
                error: uploadError
            } = await supabaseClient
                .storage
                .from("gallery")
                .upload(
                    fileName,
                    imageFile
                );


            if (uploadError) {
                throw uploadError;
            }


            // =========================
            // GET PUBLIC IMAGE URL
            // =========================

            const {
                data: publicUrlData
            } = supabaseClient
                .storage
                .from("gallery")
                .getPublicUrl(
                    fileName
                );


            const imageUrl =
                publicUrlData.publicUrl;


            // =========================
            // SAVE DATABASE RECORD
            // =========================

            const {
                error: insertError
            } = await supabaseClient
                .from("gallery")
                .insert([
                    {
                        title: title,
                        description: description,
                        image_url: imageUrl,
                        category: category,

                        // Every new gallery
                        // image is automatically active
                        is_active: true,

                        display_order: displayOrder
                    }
                ]);


            if (insertError) {
                throw insertError;
            }


            alert(
                "Gallery image added successfully."
            );


            // Reset form

            galleryForm.reset();


            // Reload gallery

            await loadGalleryImages();

        }

        catch (error) {

            console.error(
                "Gallery upload error:",
                error
            );

            alert(
                "Unable to add gallery image. Check the console for details."
            );

        }


        saveGalleryBtn.disabled = false;

        saveGalleryBtn.textContent =
            "Add Image";

    }
);

}

// =========================
// DELETE GALLERY IMAGE
// =========================

async function deleteGalleryImage(id) {

const confirmed =
    confirm(
        "Are you sure you want to delete this gallery image?"
    );


if (!confirmed) return;


// =========================
// GET IMAGE URL
// =========================

const {
    data,
    error: fetchError
} = await supabaseClient
    .from("gallery")
    .select("image_url")
    .eq("id", id)
    .maybeSingle();


if (fetchError) {

    console.error(
        "Gallery fetch error:",
        fetchError
    );

    return;
}


// =========================
// DELETE DATABASE RECORD
// =========================

const {
    error: deleteError
} = await supabaseClient
    .from("gallery")
    .delete()
    .eq("id", id);


if (deleteError) {

    console.error(
        "Gallery delete error:",
        deleteError
    );

    alert(
        "Unable to delete gallery image."
    );

    return;
}


// =========================
// DELETE IMAGE FROM STORAGE
// =========================

if (data && data.image_url) {

    try {

        const imageUrl =
            data.image_url;


        const marker =
            "/storage/v1/object/public/gallery/";


        if (imageUrl.includes(marker)) {

            const filePath =
                imageUrl.split(marker)[1];


            await supabaseClient
                .storage
                .from("gallery")
                .remove([
                    filePath
                ]);

        }

    }

    catch (storageError) {

        console.error(
            "Storage image removal error:",
            storageError
        );

    }

}


alert(
    "Gallery image deleted."
);


// Reload gallery

loadGalleryImages();

}

// =========================
// INITIAL LOAD
// =========================

document.addEventListener(
"DOMContentLoaded",
() => {

    loadGalleryImages();

}

);

window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});