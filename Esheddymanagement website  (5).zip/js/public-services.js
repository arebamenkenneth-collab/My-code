async function loadPublicServices() {

    const { data, error } = await supabaseClient
        .from("services")
        .select("*")
        .eq("is_active", true)
        .order("display_order", { ascending: true });

    if (error) {
        console.error("Public services error:", error);
        return;
    }

    const servicesList = document.getElementById("public-services-list");

    servicesList.innerHTML = "";

    data.forEach((service) => {

        const serviceCard = document.createElement("article");

        serviceCard.className = "service-card";

        serviceCard.innerHTML = `
            <h3>${service.title}</h3>

            <p>
                ${service.description}
            </p>

            <a href="#contact" class="service-link">
                Learn More →
            </a>
        `;

        servicesList.appendChild(serviceCard);
    });
}

loadPublicServices();