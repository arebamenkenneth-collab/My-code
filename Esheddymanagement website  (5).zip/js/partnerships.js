const partnershipForm = document.getElementById("partnership-form");
const partnershipList = document.getElementById("partnership-list");
const savePartnershipBtn = document.getElementById("save-partnership-btn");

async function loadPartnerships() {
    if (!partnershipList) return;

    const { data, error } = await supabaseClient
        .from("partnerships")
        .select("*")
        .order("display_order", { ascending: true })
        .order("created_at", { ascending: false });

    if (error) {
        console.error("Partnerships load error:", error);

        partnershipList.innerHTML = `
            <div class="partnership-empty">
                Unable to load partnerships.
            </div>
        `;

        return;
    }

    partnershipList.innerHTML = "";

    if (!data || data.length === 0) {
        partnershipList.innerHTML = `
            <div class="partnership-empty">
                No partnerships added yet.
            </div>
        `;

        return;
    }

    data.forEach((partnership) => {

        const card = document.createElement("div");

        card.className = "partnership-admin-card";

        card.innerHTML = `
            ${
                partnership.logo_url
                    ? `
                        <div class="partnership-admin-logo">
                            <img
                                src="${partnership.logo_url}"
                                alt="${partnership.name}"
                            >
                        </div>
                    `
                    : ""
            }

            <div class="partnership-admin-content">

                ${
                    partnership.partnership_type
                        ? `
                            <span class="partnership-admin-type">
                                ${partnership.partnership_type}
                            </span>
                        `
                        : ""
                }

                <h3>${partnership.name}</h3>

                ${
                    partnership.description
                        ? `
                            <p>
                                ${partnership.description}
                            </p>
                        `
                        : ""
                }

                ${
                    partnership.website_url
                        ? `
                            <a
                                href="${partnership.website_url}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="partnership-admin-website"
                            >
                                Visit Website
                            </a>
                        `
                        : ""
                }

                <div class="partnership-admin-actions">

                    <button
                        class="partnership-delete-btn"
                        onclick="deletePartnership(${partnership.id})"
                    >
                        Delete
                    </button>

                </div>

            </div>
        `;

        partnershipList.appendChild(card);
    });
}


if (partnershipForm) {

    partnershipForm.addEventListener("submit", async (event) => {

        event.preventDefault();

        const name = document
            .getElementById("partnership-name")
            .value
            .trim();

        const description = document
            .getElementById("partnership-description")
            .value
            .trim();

        const partnershipType = document
            .getElementById("partnership-type")
            .value;

        const websiteUrl = document
            .getElementById("partnership-website")
            .value
            .trim();

        const displayOrder = Number(
            document.getElementById("partnership-order").value
        );

        const logoInput =
            document.getElementById("partnership-logo");

        const logoFile = logoInput.files[0];


        if (!name) {

            alert("Please enter the partner name.");

            return;
        }


        savePartnershipBtn.disabled = true;

        savePartnershipBtn.textContent = "Saving...";


        try {

            let logoUrl = "";


            if (logoFile) {

                const fileExtension =
                    logoFile.name.split(".").pop();

                const fileName =
                    `partnerships/${Date.now()}-${Math.random()
                        .toString(36)
                        .substring(2, 8)}.${fileExtension}`;


                const { error: uploadError } =
                    await supabaseClient
                        .storage
                        .from("partnerships")
                        .upload(fileName, logoFile);


                if (uploadError) {

                    throw uploadError;

                }


                const { data: publicUrlData } =
                    supabaseClient
                        .storage
                        .from("partnerships")
                        .getPublicUrl(fileName);


                logoUrl =
                    publicUrlData.publicUrl;
            }


            const { error: insertError } =
                await supabaseClient
                    .from("partnerships")
                    .insert([
                        {
                            name: name,
                            description: description,
                            logo_url: logoUrl,
                            website_url: websiteUrl,
                            partnership_type: partnershipType,
                            is_active: true,
                            display_order: displayOrder
                        }
                    ]);


            if (insertError) {

                throw insertError;

            }


            alert("Partnership added successfully.");

            partnershipForm.reset();

            await loadPartnerships();


        } catch (error) {

            console.error(
                "Partnership save error:",
                error
            );

            alert(
                "Unable to add partnership. Check the console for details."
            );

        }


        savePartnershipBtn.disabled = false;

        savePartnershipBtn.textContent =
            "Add Partnership";

    });

}


async function deletePartnership(id) {

    const confirmed = confirm(
        "Are you sure you want to delete this partnership?"
    );

    if (!confirmed) return;


    const { data, error: fetchError } =
        await supabaseClient
            .from("partnerships")
            .select("logo_url")
            .eq("id", id)
            .maybeSingle();


    if (fetchError) {

        console.error(
            "Partnership fetch error:",
            fetchError
        );

        return;
    }


    const { error: deleteError } =
        await supabaseClient
            .from("partnerships")
            .delete()
            .eq("id", id);


    if (deleteError) {

        console.error(
            "Partnership delete error:",
            deleteError
        );

        alert(
            "Unable to delete partnership."
        );

        return;
    }


    if (data && data.logo_url) {

        try {

            const marker =
                "/storage/v1/object/public/partnerships/";

            if (data.logo_url.includes(marker)) {

                const filePath =
                    data.logo_url.split(marker)[1];

                await supabaseClient
                    .storage
                    .from("partnerships")
                    .remove([filePath]);

            }

        } catch (storageError) {

            console.error(
                "Storage logo removal error:",
                storageError
            );

        }

    }


    alert("Partnership deleted.");

    loadPartnerships();

}


document.addEventListener(
    "DOMContentLoaded",
    loadPartnerships
);


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});