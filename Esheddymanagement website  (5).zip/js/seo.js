const seoForm =
    document.getElementById("seo-settings-form");


async function loadSEOSettings() {

    const { data, error } = await supabaseClient
        .from("seo_settings")
        .select("*")
        .eq("id", 1)
        .maybeSingle();

    if (error) {

        console.error(
            "SEO settings load error:",
            error
        );

        return;
    }

    if (!data) {

        console.warn(
            "No SEO settings found."
        );

        return;
    }


    document.getElementById(
        "seo-site-title"
    ).value = data.site_title || "";


    document.getElementById(
        "seo-meta-description"
    ).value = data.meta_description || "";


    document.getElementById(
        "seo-keywords"
    ).value = data.keywords || "";


    document.getElementById(
        "seo-og-title"
    ).value = data.og_title || "";


    document.getElementById(
        "seo-og-description"
    ).value = data.og_description || "";


    document.getElementById(
        "seo-og-image"
    ).value = data.og_image_url || "";


    document.getElementById(
        "seo-canonical-url"
    ).value = data.canonical_url || "";

}


/* SAVE SEO SETTINGS */

document.getElementById(
    "save-seo-btn"
).addEventListener(
    "click",
    async () => {

        const button =
            document.getElementById(
                "save-seo-btn"
            );


        button.disabled = true;

        button.textContent =
            "Saving...";


        const siteTitle =
            document.getElementById(
                "seo-site-title"
            ).value.trim();


        const metaDescription =
            document.getElementById(
                "seo-meta-description"
            ).value.trim();


        const keywords =
            document.getElementById(
                "seo-keywords"
            ).value.trim();


        const ogTitle =
            document.getElementById(
                "seo-og-title"
            ).value.trim();


        const ogDescription =
            document.getElementById(
                "seo-og-description"
            ).value.trim();


        const ogImageUrl =
            document.getElementById(
                "seo-og-image"
            ).value.trim();


        const canonicalUrl =
            document.getElementById(
                "seo-canonical-url"
            ).value.trim();


        const { error } =
            await supabaseClient
                .from("seo_settings")
                .update({

                    site_title:
                        siteTitle,

                    meta_description:
                        metaDescription,

                    keywords:
                        keywords,

                    og_title:
                        ogTitle,

                    og_description:
                        ogDescription,

                    og_image_url:
                        ogImageUrl,

                    canonical_url:
                        canonicalUrl,

                    updated_at:
                        new Date().toISOString()

                })
                .eq("id", 1);


        if (error) {

            console.error(
                "SEO settings update error:",
                error
            );

            alert(
                "Unable to save SEO settings."
            );

            button.disabled = false;

            button.textContent =
                "Save SEO Settings";

            return;
        }


        alert(
            "SEO settings saved successfully."
        );


        button.disabled = false;

        button.textContent =
            "Save SEO Settings";

    }
);


loadSEOSettings();

window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});