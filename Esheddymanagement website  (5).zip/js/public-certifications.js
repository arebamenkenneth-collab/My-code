document.addEventListener("DOMContentLoaded", async () => {

    const certificationsList =
        document.getElementById(
            "public-certifications-list"
        );

    if (!certificationsList) return;


    const { data, error } =
        await supabaseClient
            .from("certifications")
            .select("*")
            .eq("is_active", true)
            .order("display_order", {
                ascending: true
            });


    if (error) {

        console.error(
            "Public certifications loading error:",
            error
        );

        return;
    }


    certificationsList.innerHTML = "";


    data.forEach((certification) => {

        const card =
            document.createElement("article");

        card.className =
            "achievement-card";


        card.innerHTML = `

            ${
                certification.image_url
                    ? `
                        <div class="achievement-image">
                            <img
                                src="${certification.image_url}"
                                alt="${certification.title}"
                            >
                        </div>
                    `
                    : `
                        <div class="achievement-icon">
                            MILE
                        </div>
                    `
            }


            <div class="achievement-content">

                <span>
                    ${certification.organization || "Achievement"}
                </span>


                <h3>
                    ${certification.title}
                </h3>


                <p>
                    ${certification.description || ""}
                </p>


                ${
                    certification.certificate_url
                        ? `
                            <a
                                href="${certification.certificate_url}"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                View Certificate →
                            </a>
                        `
                        : ""
                }

            </div>

        `;


        certificationsList.appendChild(card);

    });

});