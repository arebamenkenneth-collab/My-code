document.addEventListener("DOMContentLoaded", () => {

    const addProjectBtn =
        document.getElementById("add-project-btn");

    const addProjectForm =
        document.getElementById("add-project-form");

    const cancelProjectBtn =
        document.getElementById("cancel-project-btn");

    const saveProjectBtn =
        document.getElementById("save-project-btn");


    addProjectBtn.addEventListener("click", () => {

        addProjectForm.style.display = "block";
        addProjectBtn.style.display = "none";

    });


    cancelProjectBtn.addEventListener("click", () => {

        addProjectForm.style.display = "none";
        addProjectBtn.style.display = "block";

    });


    saveProjectBtn.addEventListener("click", async () => {

        const title =
            document.getElementById("project-title")
                .value.trim();

        const description =
            document.getElementById("project-description")
                .value.trim();

        const category =
            document.getElementById("project-category")
                .value.trim();

        const imageInput =
            document.getElementById("project-image");

        const imageFile =
            imageInput.files[0];

        const displayOrder =
            document.getElementById("project-order")
                .value;


        if (!title || !description) {

            alert(
                "Please enter the project title and description."
            );

            return;
        }


        let imageUrl = "";


        /*
         * Upload project image
         */

        if (imageFile) {

            const fileExtension =
                imageFile.name
                    .split(".")
                    .pop();

            const fileName =
                `projects/${Date.now()}-${Math.random()
                    .toString(36)
                    .substring(2)}.${fileExtension}`;


            const { error: uploadError } =
                await supabaseClient
                    .storage
                    .from("projects")
                    .upload(
                        fileName,
                        imageFile
                    );


            if (uploadError) {

                console.error(
                    "Project image upload error:",
                    uploadError
                );

                alert(
                    "Failed to upload project image: " +
                    uploadError.message
                );

                return;
            }


            const { data: publicUrlData } =
                supabaseClient
                    .storage
                    .from("projects")
                    .getPublicUrl(fileName);


            imageUrl =
                publicUrlData.publicUrl;

        }


        /*
         * Save project
         */

        const { error } =
            await supabaseClient
                .from("projects")
                .insert({

                    title: title,

                    description: description,

                    category: category,

                    image_url: imageUrl,

                    is_active: true,

                    display_order:
                        Number(displayOrder) || 0

                });


        if (error) {

            console.error(
                "Insert project error:",
                error
            );

            alert(
                "Failed to add project: " +
                error.message
            );

            return;
        }


        alert(
            "Project added successfully!"
        );


        document.getElementById(
            "project-title"
        ).value = "";

        document.getElementById(
            "project-description"
        ).value = "";

        document.getElementById(
            "project-category"
        ).value = "";

        document.getElementById(
            "project-image"
        ).value = "";

        document.getElementById(
            "project-order"
        ).value = "0";


        addProjectForm.style.display = "none";
        addProjectBtn.style.display = "block";


        loadProjects();

    });


    async function loadProjects() {

        const { data, error } =
            await supabaseClient
                .from("projects")
                .select("*")
                .order("display_order", {
                    ascending: true
                });


        if (error) {

            console.error(
                "Projects loading error:",
                error
            );

            return;
        }


        const projectsList =
            document.getElementById("projects-list");

        projectsList.innerHTML = "";


        data.forEach((project) => {

            const projectItem =
                document.createElement("div");

            projectItem.className =
                "project-item";


            projectItem.innerHTML = `

                <div class="project-info">

                    <h3>
                        ${project.title}
                    </h3>

                    <div class="project-category">
                        ${project.category || ""}
                    </div>

                    <p>
                        ${project.description || ""}
                    </p>

                </div>


                <div class="project-actions">

                    <button
                        class="edit-project"
                    >
                        Edit
                    </button>

                    <button
                        class="delete-project"
                    >
                        Delete
                    </button>

                </div>

            `;


            projectsList.appendChild(projectItem);


            const editButton =
                projectItem.querySelector(
                    ".edit-project"
                );


            editButton.addEventListener(
                "click",
                async () => {

                    const newTitle =
                        prompt(
                            "Enter project title:",
                            project.title
                        );

                    if (newTitle === null) {
                        return;
                    }


                    const newDescription =
                        prompt(
                            "Enter project description:",
                            project.description || ""
                        );

                    if (newDescription === null) {
                        return;
                    }


                    const newCategory =
                        prompt(
                            "Enter project category:",
                            project.category || ""
                        );

                    if (newCategory === null) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("projects")
                            .update({

                                title: newTitle,

                                description:
                                    newDescription,

                                category:
                                    newCategory

                            })
                            .eq(
                                "id",
                                project.id
                            );


                    if (error) {

                        console.error(
                            "Update project error:",
                            error
                        );

                        alert(
                            "Failed to update project: " +
                            error.message
                        );

                        return;
                    }


                    alert(
                        "Project updated successfully!"
                    );


                    loadProjects();

                }
            );


            const deleteButton =
                projectItem.querySelector(
                    ".delete-project"
                );


            deleteButton.addEventListener(
                "click",
                async () => {

                    const confirmed =
                        confirm(
                            `Are you sure you want to delete ${project.title}?`
                        );


                    if (!confirmed) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("projects")
                            .delete()
                            .eq(
                                "id",
                                project.id
                            );


                    if (error) {

                        console.error(
                            "Delete project error:",
                            error
                        );

                        alert(
                            "Failed to delete project: " +
                            error.message
                        );

                        return;
                    }


                    alert(
                        "Project deleted successfully!"
                    );


                    loadProjects();

                }
            );

        });

    }


    loadProjects();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});