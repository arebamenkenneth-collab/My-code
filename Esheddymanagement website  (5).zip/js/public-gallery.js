async function loadPublicGallery() {
const galleryList = document.getElementById("public-gallery-list");

if (!galleryList) return;

const { data, error } = await supabaseClient
    .from("gallery")
    .select("*")
    .eq("is_active", true)
    .order("display_order", { ascending: true })
    .order("created_at", { ascending: false });

if (error) {
    console.error("Public Gallery error:", error);
    galleryList.innerHTML = `
        <div class="gallery-empty">
            Unable to load gallery images.
        </div>
    `;
    return;
}

galleryList.innerHTML = "";

if (!data || data.length === 0) {
    galleryList.innerHTML = `
        <div class="gallery-empty">
            No gallery images available yet.
        </div>
    `;
    return;
}

data.forEach((image) => {
    const card = document.createElement("article");
    card.className = "gallery-card";

    card.innerHTML = `
        <div class="gallery-image">
            <img
    src="${image.image_url}"
    alt="${image.title}"
    loading="lazy"
    class="clickable-image"
    data-full-image="${image.image_url}"
>
        </div>

        <div class="gallery-content">

            ${
                image.category
                    ? `
                        <span class="gallery-category">
                            ${image.category}
                        </span>
                    `
                    : ""
            }

            <h3>${image.title}</h3>

            ${
                image.description
                    ? `<p>${image.description}</p>`
                    : ""
            }

        </div>
    `;

    galleryList.appendChild(card);
});

}

document.addEventListener("DOMContentLoaded", loadPublicGallery);