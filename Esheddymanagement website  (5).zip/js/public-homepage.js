async function loadPublicHomepage() {

    const { data, error } = await supabaseClient
        .from("site_settings")
        .select(
            "hero_title, hero_description"
        )
        .limit(1)
        .maybeSingle();


    if (error) {

        console.error(
            "Public homepage error:",
            error
        );

        return;
    }


    if (!data) {
        return;
    }


    const heroTitle =
        document.querySelector(".hero h1");

    const heroDescription =
        document.querySelector(".hero-description");


    // APPLY HERO TITLE

    if (data.hero_title && heroTitle) {

        heroTitle.textContent =
            data.hero_title;

    }


    // APPLY HERO DESCRIPTION

    if (data.hero_description && heroDescription) {

        heroDescription.textContent =
            data.hero_description;

    }

}


document.addEventListener(
    "DOMContentLoaded",
    loadPublicHomepage
);