document.addEventListener("DOMContentLoaded", () => {

    const addButton =
        document.getElementById(
            "add-certification-btn"
        );

    const form =
        document.getElementById(
            "add-certification-form"
        );

    const cancelButton =
        document.getElementById(
            "cancel-certification-btn"
        );

    const saveButton =
        document.getElementById(
            "save-certification-btn"
        );


    /* =========================
       SHOW FORM
    ========================== */

    addButton.addEventListener(
        "click",
        () => {

            form.style.display = "block";

            addButton.style.display = "none";

        }
    );


    /* =========================
       HIDE FORM
    ========================== */

    cancelButton.addEventListener(
        "click",
        () => {

            form.style.display = "none";

            addButton.style.display = "block";

        }
    );


    /* =========================
       SAVE CERTIFICATION
    ========================== */

    saveButton.addEventListener(
        "click",
        async () => {

            const title =
                document.getElementById(
                    "certification-title"
                ).value.trim();

            const organization =
                document.getElementById(
                    "certification-organization"
                ).value.trim();

            const description =
                document.getElementById(
                    "certification-description"
                ).value.trim();

            const imageInput =
                document.getElementById(
                    "certification-image"
                );

            const imageFile =
                imageInput.files[0];

            const certificateUrl =
                document.getElementById(
                    "certification-url"
                ).value.trim();

            const displayOrder =
                document.getElementById(
                    "certification-order"
                ).value;


            if (!title) {

                alert(
                    "Please enter the certification or achievement title."
                );

                return;

            }


            let imageUrl = "";


            /* =========================
               UPLOAD CERTIFICATION IMAGE
            ========================== */

            if (imageFile) {

                const fileExtension =
                    imageFile.name
                        .split(".")
                        .pop();

                const fileName =
                    `certificates/${Date.now()}-${Math.random()
                        .toString(36)
                        .substring(2)}.${fileExtension}`;


                const { error: uploadError } =
                    await supabaseClient
                        .storage
                        .from("certificates")
                        .upload(
                            fileName,
                            imageFile
                        );


                if (uploadError) {

                    console.error(
                        "Certification image upload error:",
                        uploadError
                    );

                    alert(
                        "Failed to upload certification image: " +
                        uploadError.message
                    );

                    return;

                }


                const { data: publicUrlData } =
                    supabaseClient
                        .storage
                        .from("certificates")
                        .getPublicUrl(fileName);


                imageUrl =
                    publicUrlData.publicUrl;

            }


            /* =========================
               SAVE TO DATABASE
            ========================== */

            const { error } =
                await supabaseClient
                    .from("certifications")
                    .insert({

                        title: title,

                        organization:
                            organization,

                        description:
                            description,

                        image_url:
                            imageUrl,

                        certificate_url:
                            certificateUrl,

                        is_active:
                            true,

                        display_order:
                            Number(displayOrder) || 0

                    });


            if (error) {

                console.error(
                    "Insert certification error:",
                    error
                );

                alert(
                    "Failed to add certification: " +
                    error.message
                );

                return;

            }


            alert(
                "Certification added successfully!"
            );


            clearForm();

            form.style.display = "none";

            addButton.style.display = "block";


            loadCertifications();

        }
    );


    /* =========================
       CLEAR FORM
    ========================== */

    function clearForm() {

        document.getElementById(
            "certification-title"
        ).value = "";

        document.getElementById(
            "certification-organization"
        ).value = "";

        document.getElementById(
            "certification-description"
        ).value = "";

        document.getElementById(
            "certification-image"
        ).value = "";

        document.getElementById(
            "certification-url"
        ).value = "";

        document.getElementById(
            "certification-order"
        ).value = "0";

    }


    /* =========================
       LOAD CERTIFICATIONS
    ========================== */

    async function loadCertifications() {

        const { data, error } =
            await supabaseClient
                .from("certifications")
                .select("*")
                .order(
                    "display_order",
                    {
                        ascending: true
                    }
                );


        if (error) {

            console.error(
                "Certifications loading error:",
                error
            );

            return;

        }


        const list =
            document.getElementById(
                "certifications-list"
            );


        list.innerHTML = "";


        data.forEach(
            (certification) => {

                const item =
                    document.createElement(
                        "div"
                    );

                item.className =
                    "certification-item";


                item.innerHTML = `

                    <div class="certification-info">

                        ${
                            certification.image_url
                                ? `
                                    <div class="certification-image-preview">
                                        <img
                                            src="${certification.image_url}"
                                            alt="${certification.title}"
                                        >
                                    </div>
                                `
                                : ""
                        }

                        <h3>
                            ${certification.title}
                        </h3>

                        <div class="certification-organization">
                            ${certification.organization || ""}
                        </div>

                        <p>
                            ${certification.description || ""}
                        </p>

                    </div>


                    <div class="certification-actions">

                        <button
                            class="edit-certification"
                        >
                            Edit
                        </button>

                        <button
                            class="delete-certification"
                        >
                            Delete
                        </button>

                    </div>

                `;


                list.appendChild(item);


                /* =========================
                   EDIT
                ========================== */

                const editButton =
                    item.querySelector(
                        ".edit-certification"
                    );


                editButton.addEventListener(
                    "click",
                    async () => {

                        const newTitle =
                            prompt(
                                "Enter certification or achievement title:",
                                certification.title
                            );


                        if (
                            newTitle === null
                        ) {
                            return;
                        }


                        const newOrganization =
                            prompt(
                                "Enter organization:",
                                certification.organization || ""
                            );


                        if (
                            newOrganization === null
                        ) {
                            return;
                        }


                        const newDescription =
                            prompt(
                                "Enter description:",
                                certification.description || ""
                            );


                        if (
                            newDescription === null
                        ) {
                            return;
                        }


                        const { error } =
                            await supabaseClient
                                .from(
                                    "certifications"
                                )
                                .update({

                                    title:
                                        newTitle,

                                    organization:
                                        newOrganization,

                                    description:
                                        newDescription

                                })
                                .eq(
                                    "id",
                                    certification.id
                                );


                        if (error) {

                            console.error(
                                "Update certification error:",
                                error
                            );

                            alert(
                                "Failed to update certification: " +
                                error.message
                            );

                            return;

                        }


                        alert(
                            "Certification updated successfully!"
                        );


                        loadCertifications();

                    }
                );


                /* =========================
                   DELETE
                ========================== */

                const deleteButton =
                    item.querySelector(
                        ".delete-certification"
                    );


                deleteButton.addEventListener(
                    "click",
                    async () => {

                        const confirmed =
                            confirm(
                                `Are you sure you want to delete "${certification.title}"?`
                            );


                        if (!confirmed) {
                            return;
                        }


                        const { error } =
                            await supabaseClient
                                .from(
                                    "certifications"
                                )
                                .delete()
                                .eq(
                                    "id",
                                    certification.id
                                );


                        if (error) {

                            console.error(
                                "Delete certification error:",
                                error
                            );

                            alert(
                                "Failed to delete certification: " +
                                error.message
                            );

                            return;

                        }


                        alert(
                            "Certification deleted successfully!"
                        );


                        loadCertifications();

                    }
                );

            }
        );

    }


    /* =========================
       INITIAL LOAD
    ========================== */

    loadCertifications();

});



window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});