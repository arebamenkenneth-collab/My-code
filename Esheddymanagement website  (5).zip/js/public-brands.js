document.addEventListener("DOMContentLoaded", async () => {

    const brandsList =
        document.getElementById("public-brands-list");

    if (!brandsList) return;


    const { data, error } =
        await supabaseClient
            .from("brands")
            .select("*")
            .eq("is_active", true)
            .order("display_order", {
                ascending: true
            });


    if (error) {
        console.error(
            "Public brands loading error:",
            error
        );
        return;
    }


    brandsList.innerHTML = "";


    data.forEach((brand) => {

        const brandCard =
            document.createElement("article");

        brandCard.className = "brand-card";


        brandCard.innerHTML = `

            <div class="brand-placeholder">

                ${
                    brand.logo_url
                        ? `
                            <img
                                src="${brand.logo_url}"
                                alt="${brand.name}"
                            >
                        `
                        : `
                            <span>
                                ${brand.name}
                            </span>
                        `
                }

            </div>


            <div class="brand-content">

                <h3>
                    ${brand.name}
                </h3>

                <p>
                    ${brand.description || ""}
                </p>

                ${
                    brand.website_url
                        ? `
                            <a
                                href="${brand.website_url}"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                Visit Website →
                            </a>
                        `
                        : ""
                }

            </div>

        `;


        brandsList.appendChild(brandCard);

    });

});