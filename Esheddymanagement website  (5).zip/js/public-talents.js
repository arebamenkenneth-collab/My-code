async function loadPublicTalents() {

    const { data, error } = await supabaseClient
        .from("talents")
        .select("*")
        .eq("is_active", true)
        .order("display_order", { ascending: true });


    if (error) {

        console.error("Public talents error:", error);

        return;
    }


    const talentsList = document.getElementById(
        "public-talents-list"
    );


    if (!talentsList) {
        return;
    }


    talentsList.innerHTML = "";


    data.forEach((talent) => {

        const talentCard = document.createElement("article");

        talentCard.className = "talent-card";


        talentCard.innerHTML = `

            <div class="talent-card-image">

                ${
                    talent.image_url
                    ? `<img
                        src="${talent.image_url}"
                        alt="${talent.name}"
                    >`
                    : ""
                }

            </div>


            <div class="talent-card-content">

                <p class="talent-card-category">
                    ${talent.category}
                </p>

                <h3>
                    ${talent.name}
                </h3>

                <p>
                    ${talent.bio}
                </p>

            </div>

        `;


        talentsList.appendChild(talentCard);

    });

}


loadPublicTalents();