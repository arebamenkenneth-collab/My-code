document.addEventListener("DOMContentLoaded", async () => {

    const bookingsList =
        document.getElementById("bookings-list");

    if (!bookingsList) return;

    bookingsList.innerHTML =
        "<p>Loading bookings...</p>";

    const { data, error } =
        await supabaseClient
            .from("bookings")
            .select("*")
            .order("created_at", {
                ascending: false
            });

    if (error) {

        console.error(
            "Bookings loading error:",
            error
        );

        bookingsList.innerHTML = `
            <p>
                Unable to load bookings.
            </p>
        `;

        return;
    }

    if (!data || data.length === 0) {

        bookingsList.innerHTML = `
            <p>
                No bookings or inquiries yet.
            </p>
        `;

        return;
    }

    bookingsList.innerHTML = "";

    data.forEach((booking) => {

        const card =
            document.createElement("article");

        card.className =
            "booking-admin-card";

        card.innerHTML = `

            <div class="booking-admin-header">

                <div>

                    <h3>
                        ${booking.name}
                    </h3>

                    <span>
                        ${new Date(
                            booking.created_at
                        ).toLocaleString()}
                    </span>

                </div>

                <select
                    class="booking-status-select"
                    data-id="${booking.id}"
                >

                    <option value="pending"
                        ${booking.status === "pending" ? "selected" : ""}>
                        Pending
                    </option>

                    <option value="contacted"
                        ${booking.status === "contacted" ? "selected" : ""}>
                        Contacted
                    </option>

                    <option value="completed"
                        ${booking.status === "completed" ? "selected" : ""}>
                        Completed
                    </option>

                </select>

            </div>


            <div class="booking-admin-details">

                <div class="booking-detail">

                    <strong>Email</strong>

                    <span>
                        ${booking.email}
                    </span>

                </div>


                <div class="booking-detail">

                    <strong>Phone / WhatsApp</strong>

                    <span>
                        ${booking.phone || "Not provided"}
                    </span>

                </div>


                <div class="booking-detail">

                    <strong>Inquiry Type</strong>

                    <span>
                        ${booking.service || "Not specified"}
                    </span>

                </div>

            </div>


            <div class="booking-admin-message">

                <strong>Message</strong>

                <p>
                    ${booking.message}
                </p>

            </div>


            <div class="booking-admin-actions">

                <button
                    type="button"
                    class="delete-booking"
                    data-id="${booking.id}"
                >
                    Delete Booking
                </button>

            </div>

        `;

        bookingsList.appendChild(card);

    });


    /*
        STATUS MANAGEMENT
    */

    const statusSelectors =
        document.querySelectorAll(
            ".booking-status-select"
        );

    statusSelectors.forEach((select) => {

        select.addEventListener(
            "change",
            async () => {

                const bookingId =
                    select.dataset.id;

                const newStatus =
                    select.value;

                const { error } =
                    await supabaseClient
                        .from("bookings")
                        .update({
                            status: newStatus
                        })
                        .eq(
                            "id",
                            bookingId
                        );

                if (error) {

                    console.error(
                        "Status update error:",
                        error
                    );

                    alert(
                        "Update failed: " +
                        error.message
                    );

                    return;
                }

                console.log(
                    "Booking status updated:",
                    newStatus
                );

            }
        );

    });
    
        /*
        DELETE BOOKING
    */

    const deleteButtons =
        document.querySelectorAll(
            ".delete-booking"
        );

    deleteButtons.forEach((button) => {

        button.addEventListener(
            "click",
            async () => {

                const bookingId =
                    button.dataset.id;

                const confirmed =
                    confirm(
                        "Are you sure you want to delete this booking?"
                    );

                if (!confirmed) return;

                const { error } =
                    await supabaseClient
                        .from("bookings")
                        .delete()
                        .eq(
                            "id",
                            bookingId
                        );

                if (error) {

                    console.error(
                        "Booking delete error:",
                        error
                    );

                    alert(
                        "Unable to delete booking: " +
                        error.message
                    );

                    return;
                }

                const bookingCard =
                    button.closest(
                        ".booking-admin-card"
                    );

                if (bookingCard) {
                    bookingCard.remove();
                }

            }
        );

    });

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});