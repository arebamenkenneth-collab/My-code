const settingsForm = document.getElementById("settings-form");

const logoFileInput = document.getElementById("logo-file");
const uploadLogoButton = document.getElementById("upload-logo-btn");
const logoStatus = document.getElementById("logo-status");
const logoPreview = document.getElementById("logo-preview");

/* LOAD COMPANY SETTINGS */

async function loadSettings() {

const { data, error } = await supabaseClient
    .from("site_settings")
    .select("*")
    .eq("id", 1)
    .maybeSingle();

if (error) {

    console.error("Settings load error:", error);

    return;
}

if (!data) {

    console.warn("No site settings record found.");

    return;
}


document.getElementById("company-name").value =
    data.company_name || "";

document.getElementById("company-tagline").value =
    data.tagline || "";

document.getElementById("company-description").value =
    data.description || "";

document.getElementById("company-mission").value =
    data.mission || "";

document.getElementById("company-vision").value =
    data.vision || "";

document.getElementById("company-location").value =
    data.location || "";

document.getElementById("company-email").value =
    data.email || "";

document.getElementById("company-phone").value =
    data.phone || "";

document.getElementById("company-whatsapp").value =
    data.whatsapp || "";


/* LOAD CURRENT LOGO */

if (data.logo_url) {

    logoPreview.innerHTML = `
        <p style="margin-bottom:10px; color:var(--text-muted);">
            Current Logo
        </p>

        <img
            src="${data.logo_url}"
            alt="Current company logo"
            style="
                max-width:220px;
                max-height:120px;
                object-fit:contain;
                display:block;
                border:1px solid var(--border);
                border-radius:8px;
                padding:10px;
                background:#fff;
            "
        >
    `;

} else {

    logoPreview.innerHTML = `
        <p style="color:var(--text-muted);">
            No company logo uploaded yet.
        </p>
    `;
}

}

/* SAVE COMPANY INFORMATION */

settingsForm.addEventListener("submit", async (event) => {

event.preventDefault();

const button =
    document.getElementById("save-settings-btn");

button.disabled = true;
button.textContent = "Saving...";


const updates = {

    company_name:
        document.getElementById("company-name").value.trim(),

    tagline:
        document.getElementById("company-tagline").value.trim(),

    description:
        document.getElementById("company-description").value.trim(),

    mission:
        document.getElementById("company-mission").value.trim(),

    vision:
        document.getElementById("company-vision").value.trim(),

    location:
        document.getElementById("company-location").value.trim(),

    email:
        document.getElementById("company-email").value.trim(),

    phone:
        document.getElementById("company-phone").value.trim(),

    whatsapp:
        document.getElementById("company-whatsapp").value.trim()

};


const { error } = await supabaseClient
    .from("site_settings")
    .update(updates)
    .eq("id", 1);


if (error) {

    console.error(
        "Settings save error:",
        error
    );

    alert(
        "Unable to save company information."
    );

    button.disabled = false;
    button.textContent =
        "Save Company Information";

    return;
}


alert(
    "Company information saved successfully."
);

button.disabled = false;
button.textContent =
    "Save Company Information";

});

/* UPLOAD LOGO */

uploadLogoButton.addEventListener(
"click",
async () => {

    const file = logoFileInput.files[0];


    if (!file) {

        alert("Please select a logo image first.");

        return;
    }


    /* CHECK FILE TYPE */

    if (!file.type.startsWith("image/")) {

        alert("Please select a valid image file.");

        return;
    }


    uploadLogoButton.disabled = true;
    uploadLogoButton.textContent = "Uploading...";

    logoStatus.textContent =
        "Uploading logo...";


    try {

        /*
         * Create a unique file name.
         * This prevents conflicts with previously
         * uploaded logo files.
         */

        const fileExtension =
            file.name.split(".").pop();

        const fileName =
            `logo-${Date.now()}.${fileExtension}`;


        const filePath =
            `company/${fileName}`;


        /* UPLOAD TO SUPABASE STORAGE */

        const { error: uploadError } =
            await supabaseClient.storage
                .from("logo")
                .upload(
                    filePath,
                    file,
                    {
                        cacheControl: "3600",
                        upsert: false
                    }
                );


        if (uploadError) {

            console.error(
                "Logo upload error:",
                uploadError
            );

            logoStatus.textContent =
                "Logo upload failed.";

            alert(
                "Unable to upload logo."
            );

            return;
        }


        /* GET PUBLIC URL */

        const { data: publicUrlData } =
            supabaseClient.storage
                .from("logo")
                .getPublicUrl(filePath);


        const logoUrl =
            publicUrlData.publicUrl;


        /* SAVE URL TO SITE SETTINGS */

        const { error: updateError } =
            await supabaseClient
                .from("site_settings")
                .update({
                    logo_url: logoUrl
                })
                .eq("id", 1);


        if (updateError) {

            console.error(
                "Logo URL update error:",
                updateError
            );

            logoStatus.textContent =
                "Logo uploaded, but the URL could not be saved.";

            alert(
                "Logo uploaded, but saving the logo URL failed."
            );

            return;
        }


        /* UPDATE PREVIEW */

        logoPreview.innerHTML = `

            <p style="margin-bottom:10px; color:var(--text-muted);">
                Current Logo
            </p>

            <img
                src="${logoUrl}"
                alt="Current company logo"
                style="
                    max-width:220px;
                    max-height:120px;
                    object-fit:contain;
                    display:block;
                    border:1px solid var(--border);
                    border-radius:8px;
                    padding:10px;
                    background:#fff;
                "
            >

        `;


        logoStatus.textContent =
            "Logo uploaded successfully.";

        logoFileInput.value = "";


        alert(
            "Logo uploaded and saved successfully."
        );


    } catch (error) {

        console.error(
            "Unexpected logo error:",
            error
        );

        logoStatus.textContent =
            "An unexpected error occurred.";

        alert(
            "Something went wrong while uploading the logo."
        );

    } finally {

        uploadLogoButton.disabled = false;

        uploadLogoButton.textContent =
            "Upload Logo";

    }

}

);

/* START */

loadSettings();

window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});