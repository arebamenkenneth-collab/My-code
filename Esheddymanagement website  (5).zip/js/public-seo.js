async function loadPublicSEO() {

    const { data, error } = await supabaseClient
        .from("seo_settings")
        .select("*")
        .eq("id", 1)
        .maybeSingle();

    if (error) {

        console.error(
            "Public SEO error:",
            error
        );

        return;
    }

    if (!data) {

        console.warn(
            "No SEO settings found."
        );

        return;
    }


    /* PAGE TITLE */

    document.title =
    data.site_title ||
    "ESheddy Management & Consulting";

    /* META DESCRIPTION */

    const metaDescription =
        document.getElementById(
            "meta-description"
        );

    if (metaDescription) {

        metaDescription.setAttribute(
            "content",
            data.meta_description || ""
        );

    }


    /* KEYWORDS */

    const metaKeywords =
        document.getElementById(
            "meta-keywords"
        );

    if (metaKeywords) {

        metaKeywords.setAttribute(
            "content",
            data.keywords || ""
        );

    }


    /* OPEN GRAPH TITLE */

    const ogTitle =
        document.getElementById(
            "og-title"
        );

    if (ogTitle) {

        ogTitle.setAttribute(
            "content",
            data.og_title || ""
        );

    }


    /* OPEN GRAPH DESCRIPTION */

    const ogDescription =
        document.getElementById(
            "og-description"
        );

    if (ogDescription) {

        ogDescription.setAttribute(
            "content",
            data.og_description || ""
        );

    }


    /* OPEN GRAPH IMAGE */

    const ogImage =
        document.getElementById(
            "og-image"
        );

    if (ogImage && data.og_image_url) {

        ogImage.setAttribute(
            "content",
            data.og_image_url
        );

    }


    /* CANONICAL URL */

    const canonicalUrl =
        document.getElementById(
            "canonical-url"
        );

    if (
        canonicalUrl &&
        data.canonical_url
    ) {

        canonicalUrl.setAttribute(
            "href",
            data.canonical_url
        );

    }

}


document.addEventListener(
    "DOMContentLoaded",
    loadPublicSEO
);