const campaignForm = document.getElementById("campaign-form");
const campaignList = document.getElementById("campaign-list");
const saveCampaignBtn = document.getElementById("save-campaign-btn");

// =========================
// LOAD CAMPAIGNS
// =========================

async function loadCampaigns() {
if (!campaignList) return;

const { data, error } = await supabaseClient
    .from("campaigns")
    .select("*")
    .order("display_order", { ascending: true })
    .order("created_at", { ascending: false });

if (error) {
    console.error("Campaign load error:", error);
    campaignList.innerHTML = "<p>Unable to load campaigns.</p>";
    return;
}

campaignList.innerHTML = "";

if (!data || data.length === 0) {
    campaignList.innerHTML = "<p>No campaigns or events yet.</p>";
    return;
}

data.forEach((campaign) => {

    const card = document.createElement("div");
    card.className = "campaign-admin-card";

    card.innerHTML = `
        <div class="campaign-admin-image">
            <img
                src="${campaign.image_url}"
                alt="${campaign.title}"
            >
        </div>

        <div class="campaign-admin-content">

            ${
                campaign.category
                    ? `
                        <span class="campaign-admin-category">
                            ${campaign.category}
                        </span>
                    `
                    : ""
            }

            <h3>${campaign.title}</h3>

            ${
                campaign.description
                    ? `<p>${campaign.description}</p>`
                    : ""
            }

            ${
                campaign.event_date
                    ? `
                        <p class="campaign-admin-date">
                            Date: ${campaign.event_date}
                        </p>
                    `
                    : ""
            }

            ${
                campaign.location
                    ? `
                        <p class="campaign-admin-location">
                            Location: ${campaign.location}
                        </p>
                    `
                    : ""
            }

            <div class="campaign-admin-actions">

                <button
                    class="campaign-delete-btn"
                    onclick="deleteCampaign(${campaign.id})"
                >
                    Delete
                </button>

            </div>

        </div>
    `;

    campaignList.appendChild(card);
});

}

// =========================
// ADD CAMPAIGN
// =========================

if (campaignForm) {

campaignForm.addEventListener("submit", async (event) => {

    event.preventDefault();

    const title =
        document.getElementById("campaign-title").value.trim();

    const description =
        document.getElementById("campaign-description").value.trim();

    const category =
        document.getElementById("campaign-category").value.trim();

    const eventDate =
        document.getElementById("campaign-date").value;

    const location =
        document.getElementById("campaign-location").value.trim();

    const imageInput =
        document.getElementById("campaign-image");

    const displayOrder =
        Number(
            document.getElementById("campaign-order").value
        );

    const imageFile =
        imageInput.files[0];


    if (!title || !imageFile) {

        alert(
            "Please enter a title and select an image."
        );

        return;
    }


    saveCampaignBtn.disabled = true;
    saveCampaignBtn.textContent = "Uploading...";


    try {

        // =========================
        // UPLOAD IMAGE
        // =========================

        const fileExtension =
            imageFile.name.split(".").pop();

        const fileName =
            `campaigns/${Date.now()}-${Math.random()
                .toString(36)
                .substring(2, 8)}.${fileExtension}`;


        const { error: uploadError } =
            await supabaseClient
                .storage
                .from("campaigns")
                .upload(
                    fileName,
                    imageFile
                );


        if (uploadError) {
            throw uploadError;
        }


        // =========================
        // GET PUBLIC URL
        // =========================

        const { data: publicUrlData } =
            supabaseClient
                .storage
                .from("campaigns")
                .getPublicUrl(fileName);


        const imageUrl =
            publicUrlData.publicUrl;


        // =========================
        // SAVE DATABASE RECORD
        // =========================

        const { error: insertError } =
            await supabaseClient
                .from("campaigns")
                .insert([
                    {
                        title: title,
                        description: description,
                        image_url: imageUrl,
                        category: category,
                        event_date: eventDate || null,
                        location: location,
                        is_active: true,
                        display_order: displayOrder
                    }
                ]);


        if (insertError) {
            throw insertError;
        }


        alert(
            "Campaign or event added successfully."
        );


        campaignForm.reset();


        await loadCampaigns();

    }

    catch (error) {

        console.error(
            "Campaign upload error:",
            error
        );

        alert(
            "Unable to add campaign. Check the console for details."
        );

    }


    saveCampaignBtn.disabled = false;
    saveCampaignBtn.textContent = "Add Campaign";

});

}

// =========================
// DELETE CAMPAIGN
// =========================

async function deleteCampaign(id) {

const confirmed =
    confirm(
        "Are you sure you want to delete this campaign?"
    );


if (!confirmed) return;


const { data, error: fetchError } =
    await supabaseClient
        .from("campaigns")
        .select("image_url")
        .eq("id", id)
        .maybeSingle();


if (fetchError) {

    console.error(
        "Campaign fetch error:",
        fetchError
    );

    return;
}


// Delete database record

const { error: deleteError } =
    await supabaseClient
        .from("campaigns")
        .delete()
        .eq("id", id);


if (deleteError) {

    console.error(
        "Campaign delete error:",
        deleteError
    );

    alert(
        "Unable to delete campaign."
    );

    return;
}


// Remove image from Storage

if (data && data.image_url) {

    try {

        const marker =
            "/storage/v1/object/public/campaigns/";

        if (data.image_url.includes(marker)) {

            const filePath =
                data.image_url.split(marker)[1];


            await supabaseClient
                .storage
                .from("campaigns")
                .remove([
                    filePath
                ]);

        }

    }

    catch (storageError) {

        console.error(
            "Storage removal error:",
            storageError
        );

    }

}


alert(
    "Campaign deleted."
);


loadCampaigns();

}

// =========================
// INITIAL LOAD
// =========================

document.addEventListener(
"DOMContentLoaded",
loadCampaigns
);


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});