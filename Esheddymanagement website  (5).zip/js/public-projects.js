document.addEventListener("DOMContentLoaded", async () => {

const projectsList =
    document.getElementById("public-projects-list");

if (!projectsList) {
    return;
}

const { data, error } =
    await supabaseClient
        .from("projects")
        .select("*")
        .eq("is_active", true)
        .order("display_order", {
            ascending: true
        });

if (error) {

    console.error(
        "Public projects loading error:",
        error
    );

    return;
}

projectsList.innerHTML = "";

if (!data || data.length === 0) {

    projectsList.innerHTML = `
        <p>
            Our latest work will appear here soon.
        </p>
    `;

    return;
}

data.forEach((project) => {

    const projectCard =
        document.createElement("article");

    projectCard.className =
        "portfolio-card";

    projectCard.innerHTML = `

        <div class="portfolio-image">

            ${
                project.image_url
                    ? `
                        <img
    src="${project.image_url}"
    alt="${project.title}"
    class="clickable-image"
    data-full-image="${project.image_url}"
>
                    `
                    : `
                        <div class="portfolio-placeholder">
                            Project Image
                        </div>
                    `
            }

        </div>

        <div class="portfolio-content">

            <span>
                ${project.category || "PROJECT"}
            </span>

            <h3>
                ${project.title}
            </h3>

            <p>
                ${project.description || ""}
            </p>

            <a
                href="#contact"
                class="service-link"
            >
                Work With Us →
            </a>

        </div>

    `;

    projectsList.appendChild(projectCard);

});

});