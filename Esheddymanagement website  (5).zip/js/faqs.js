document.addEventListener("DOMContentLoaded", () => {

    const addFaqBtn = document.getElementById("add-faq-btn");
    const addFaqForm = document.getElementById("add-faq-form");
    const cancelFaqBtn = document.getElementById("cancel-faq-btn");
    const saveFaqBtn = document.getElementById("save-faq-btn");


    // SHOW FAQ FORM

    addFaqBtn.addEventListener("click", () => {

        addFaqForm.style.display = "block";

    });


    // HIDE FAQ FORM

    cancelFaqBtn.addEventListener("click", () => {

        addFaqForm.style.display = "none";

    });


    // ADD FAQ

    saveFaqBtn.addEventListener("click", async () => {

        const question =
            document.getElementById("faq-question").value.trim();

        const answer =
            document.getElementById("faq-answer").value.trim();

        const displayOrder =
            document.getElementById("faq-order").value;


        if (!question || !answer) {

            alert("Please enter the question and answer.");

            return;

        }


        const { error } = await supabaseClient
            .from("faqs")
            .insert({
                question: question,
                answer: answer,
                display_order: Number(displayOrder) || 0,
                is_active: true
            });


        if (error) {

            console.error("Insert error:", error);

            alert("Failed to add FAQ: " + error.message);

            return;

        }


        alert("FAQ added successfully!");


        document.getElementById("faq-question").value = "";

        document.getElementById("faq-answer").value = "";

        document.getElementById("faq-order").value = "0";


        addFaqForm.style.display = "none";


        loadFaqs();

    });


    // LOAD FAQS

    async function loadFaqs() {

        const { data, error } = await supabaseClient
            .from("faqs")
            .select("*")
            .order("display_order", {
                ascending: true
            });


        if (error) {

            console.error("FAQs error:", error);

            return;

        }


        const faqsList =
            document.getElementById("faqs-list");


        faqsList.innerHTML = "";


        data.forEach((faq) => {

            const faqItem =
                document.createElement("div");


            faqItem.innerHTML = `

                <div>

                    <h3>
                        ${faq.question}
                    </h3>

                    <p>
                        ${faq.answer}
                    </p>

                </div>


                <div class="faq-actions">

                    <button class="edit-faq">
                        Edit
                    </button>

                    <button class="delete-faq">
                        Delete
                    </button>

                </div>

            `;


            faqsList.appendChild(faqItem);


            // EDIT FAQ

            const editButton =
                faqItem.querySelector(".edit-faq");


            editButton.addEventListener("click", async () => {

                const newQuestion = prompt(
                    "Enter new FAQ question:",
                    faq.question
                );


                if (newQuestion === null) {
                    return;
                }


                const newAnswer = prompt(
                    "Enter new FAQ answer:",
                    faq.answer
                );


                if (newAnswer === null) {
                    return;
                }


                const { error } = await supabaseClient
                    .from("faqs")
                    .update({
                        question: newQuestion,
                        answer: newAnswer
                    })
                    .eq("id", faq.id);


                if (error) {

                    console.error(
                        "Update error:",
                        error
                    );

                    alert(
                        "Failed to update FAQ: " +
                        error.message
                    );

                    return;

                }


                alert(
                    "FAQ updated successfully!"
                );


                loadFaqs();

            });


            // DELETE FAQ

            const deleteButton =
                faqItem.querySelector(".delete-faq");


            deleteButton.addEventListener("click", async () => {

                const confirmed = confirm(
                    `Are you sure you want to delete this FAQ?`
                );


                if (!confirmed) {
                    return;
                }


                const { error } = await supabaseClient
                    .from("faqs")
                    .delete()
                    .eq("id", faq.id);


                if (error) {

                    console.error(
                        "Delete error:",
                        error
                    );

                    alert(
                        "Failed to delete FAQ: " +
                        error.message
                    );

                    return;

                }


                alert(
                    "FAQ deleted successfully!"
                );


                loadFaqs();

            });

        });

    }


    // INITIAL LOAD

    loadFaqs();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});