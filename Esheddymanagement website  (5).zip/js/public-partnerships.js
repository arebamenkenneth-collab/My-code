async function loadPublicPartnerships() {
    const partnershipsList = document.getElementById(
        "public-partnerships-list"
    );

    if (!partnershipsList) return;

    const { data, error } = await supabaseClient
        .from("partnerships")
        .select("*")
        .eq("is_active", true)
        .order("display_order", { ascending: true })
        .order("created_at", { ascending: false });

    if (error) {
        console.error("Public Partnerships error:", error);

        partnershipsList.innerHTML = `
            <div class="partnerships-empty">
                Unable to load partnerships.
            </div>
        `;

        return;
    }

    partnershipsList.innerHTML = "";

    if (!data || data.length === 0) {
        partnershipsList.innerHTML = `
            <div class="partnerships-empty">
                No partnerships available yet.
            </div>
        `;

        return;
    }

    data.forEach((partnership) => {
        const card = document.createElement("article");

        card.className = "partnership-card";

        card.innerHTML = `
            ${
                partnership.logo_url
                    ? `
                        <div class="partnership-logo">
                            <img
                                src="${partnership.logo_url}"
                                alt="${partnership.name}"
                                loading="lazy"
                            >
                        </div>
                    `
                    : ""
            }

            <div class="partnership-content">

                ${
                    partnership.partnership_type
                        ? `
                            <span class="partnership-type">
                                ${partnership.partnership_type}
                            </span>
                        `
                        : ""
                }

                <h3>${partnership.name}</h3>

                ${
                    partnership.description
                        ? `
                            <p>
                                ${partnership.description}
                            </p>
                        `
                        : ""
                }

                ${
                    partnership.website_url
                        ? `
                            <a
                                href="${partnership.website_url}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="partnership-link"
                            >
                                Visit Partner Website →
                            </a>
                        `
                        : ""
                }

            </div>
        `;

        partnershipsList.appendChild(card);
    });
}


document.addEventListener(
    "DOMContentLoaded",
    loadPublicPartnerships
);