document.addEventListener("DOMContentLoaded", () => {

/* =========================
   MOBILE NAVIGATION
========================= */

const menuToggle =
    document.querySelector(".menu-toggle");

const mainNav =
    document.querySelector(".main-nav");

const navLinks =
    document.querySelectorAll(".main-nav a");


if (menuToggle && mainNav) {

    menuToggle.addEventListener("click", () => {

        mainNav.classList.toggle("mobile-open");

        const isOpen =
            mainNav.classList.contains("mobile-open");

        menuToggle.textContent =
            isOpen ? "×" : "☰";

        menuToggle.setAttribute(
            "aria-label",
            isOpen
                ? "Close navigation menu"
                : "Open navigation menu"
        );

    });


    navLinks.forEach((link) => {

        link.addEventListener("click", () => {

            mainNav.classList.remove(
                "mobile-open"
            );

            menuToggle.textContent = "☰";

            menuToggle.setAttribute(
                "aria-label",
                "Open navigation menu"
            );

        });

    });

}


/* =========================
   FAQ
========================= */

const faqQuestions =
    document.querySelectorAll(".faq-question");

faqQuestions.forEach((question) => {

    question.addEventListener("click", () => {

        const faqItem =
            question.parentElement;

        faqItem.classList.toggle("active");

    });

});


/* =========================
   BACK TO TOP
========================= */

const backToTop =
    document.querySelector(".back-to-top");


if (backToTop) {

    window.addEventListener("scroll", () => {

        if (window.scrollY > 500) {

            backToTop.classList.add("show");

        } else {

            backToTop.classList.remove("show");

        }

    });


    backToTop.addEventListener(
        "click",
        () => {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        }
    );

}

});


/* =========================
   BOOKING FORM
========================= */

const bookingForm =
    document.getElementById("booking-form");

if (bookingForm) {

    bookingForm.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();

            const name =
                document.getElementById(
                    "booking-name"
                ).value.trim();

            const email =
                document.getElementById(
                    "booking-email"
                ).value.trim();

            const phone =
                document.getElementById(
                    "booking-phone"
                ).value.trim();

            const service =
                document.getElementById(
                    "booking-service"
                ).value;

            const message =
                document.getElementById(
                    "booking-message"
                ).value.trim();

            const formMessage =
                document.getElementById(
                    "booking-form-message"
                );

            formMessage.textContent =
                "Submitting...";

            const { error } =
                await supabaseClient
                    .from("bookings")
                    .insert([
                        {
                            name: name,
                            email: email,
                            phone: phone,
                            service: service,
                            message: message
                        }
                    ]);

            if (error) {

                console.error(
                    "Booking submission error:",
                    error
                );

                formMessage.textContent =
                    "Something went wrong. Please try again.";

                return;
            }

            formMessage.textContent =
                "Your inquiry has been submitted successfully.";

            bookingForm.reset();

        }
    );

}


/* =========================
   CONTACT FORM
========================= */

const contactForm =
    document.getElementById("contact-form");

if (contactForm) {

    contactForm.addEventListener(
        "submit",
        async (event) => {

            event.preventDefault();

            const name =
                document.getElementById(
                    "contact-name"
                ).value.trim();

            const email =
                document.getElementById(
                    "contact-email"
                ).value.trim();

            const phone =
                document.getElementById(
                    "contact-phone"
                ).value.trim();

            const company =
                document.getElementById(
                    "contact-company"
                ).value.trim();

            const inquiryType =
                document.getElementById(
                    "contact-type"
                ).value;

            const message =
                document.getElementById(
                    "contact-message"
                ).value.trim();

            const formMessage =
                document.getElementById(
                    "contact-form-message"
                );

            formMessage.textContent =
                "Sending...";

            const { error } =
                await supabaseClient
                    .from("messages")
                    .insert([
                        {
                            name: name,
                            email: email,
                            phone: phone,
                            company: company,
                            inquiry_type: inquiryType,
                            message: message
                        }
                    ]);

            if (error) {

                console.error(
                    "Contact message error:",
                    error
                );

                formMessage.textContent =
                    "Something went wrong. Please try again.";

                return;
            }

            formMessage.textContent =
                "Your inquiry has been sent successfully.";

            contactForm.reset();

        }
    );

}