async function loadPublicCampaigns() {

const campaignsList =
    document.getElementById("public-campaigns-list");

if (!campaignsList) return;


const { data, error } =
    await supabaseClient
        .from("campaigns")
        .select("*")
        .eq("is_active", true)
        .order("display_order", {
            ascending: true
        })
        .order("created_at", {
            ascending: false
        });


if (error) {

    console.error(
        "Public Campaigns error:",
        error
    );

    campaignsList.innerHTML = `
        <div class="campaigns-empty">
            Unable to load campaigns and events.
        </div>
    `;

    return;
}


campaignsList.innerHTML = "";


if (!data || data.length === 0) {

    campaignsList.innerHTML = `
        <div class="campaigns-empty">
            No campaigns or events available yet.
        </div>
    `;

    return;
}


data.forEach((campaign) => {

    const card =
        document.createElement("article");

    card.className =
        "campaign-card";


    card.innerHTML = `

        <div class="campaign-image">

    <img
        src="${campaign.image_url}"
        alt="${campaign.title}"
        loading="lazy"
        class="clickable-image"
        data-full-image="${campaign.image_url}"
    >

</div>

        </div>


        <div class="campaign-content">

            ${
                campaign.category
                    ? `
                        <span class="campaign-category">
                            ${campaign.category}
                        </span>
                    `
                    : ""
            }


            <h3>
                ${campaign.title}
            </h3>


            ${
                campaign.description
                    ? `
                        <p>
                            ${campaign.description}
                        </p>
                    `
                    : ""
            }


            ${
                campaign.event_date
                    ? `
                        <p class="campaign-date">
                            Date:
                            ${campaign.event_date}
                        </p>
                    `
                    : ""
            }


            ${
                campaign.location
                    ? `
                        <p class="campaign-location">
                            Location:
                            ${campaign.location}
                        </p>
                    `
                    : ""
            }

        </div>

    `;


    campaignsList.appendChild(card);

});

}

document.addEventListener(
"DOMContentLoaded",
loadPublicCampaigns
);

// =========================================
// FULLSCREEN IMAGE VIEWER
// =========================================

document.addEventListener("click", function (event) {

    const image = event.target.closest(".clickable-image");

    if (!image) return;

    const imageUrl =
        image.dataset.fullImage || image.src;

    const lightbox =
        document.createElement("div");

    lightbox.className =
        "image-lightbox active";

    lightbox.innerHTML = `
        <button
            class="image-lightbox-close"
            aria-label="Close image"
        >
            &times;
        </button>

        <img
            src="${imageUrl}"
            alt="${image.alt || "Full size image"}"
        >
    `;

    document.body.appendChild(lightbox);

    const closeLightbox = () => {
        lightbox.classList.remove("active");

        setTimeout(() => {
            lightbox.remove();
        }, 250);
    };

    lightbox
        .querySelector(".image-lightbox-close")
        .addEventListener("click", closeLightbox);

    lightbox.addEventListener("click", function (event) {

        if (event.target === lightbox) {
            closeLightbox();
        }

    });

});