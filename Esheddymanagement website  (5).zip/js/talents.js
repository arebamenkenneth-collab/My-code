document.addEventListener("DOMContentLoaded", () => {

    const addTalentBtn =
        document.getElementById("add-talent-btn");

    const addTalentForm =
        document.getElementById("add-talent-form");

    const cancelTalentBtn =
        document.getElementById("cancel-talent-btn");

    const saveTalentBtn =
        document.getElementById("save-talent-btn");


    // =========================
    // SHOW ADD TALENT FORM
    // =========================

    addTalentBtn.addEventListener("click", () => {

        addTalentForm.style.display = "block";

    });


    // =========================
    // HIDE ADD TALENT FORM
    // =========================

    cancelTalentBtn.addEventListener("click", () => {

        addTalentForm.style.display = "none";

    });


    // =========================
    // ADD TALENT
    // =========================

    saveTalentBtn.addEventListener("click", async () => {

        const name =
            document
                .getElementById("talent-name")
                .value
                .trim();

        const category =
            document
                .getElementById("talent-category")
                .value
                .trim();

        const bio =
            document
                .getElementById("talent-bio")
                .value
                .trim();

        const imageFile =
            document
                .getElementById("talent-image")
                .files[0];

        const displayOrder =
            document
                .getElementById("talent-order")
                .value;


        // =========================
        // VALIDATION
        // =========================

        if (!name || !category || !bio) {

            alert(
                "Please enter the talent name, category, and bio."
            );

            return;
        }


        // =========================
        // IMAGE URL
        // =========================

        let imageUrl = "";


        // =========================
        // UPLOAD IMAGE
        // =========================

        if (imageFile) {

            const fileExtension =
                imageFile.name
                    .split(".")
                    .pop();

            const fileName =
                `${Date.now()}-${Math.random()
                    .toString(36)
                    .substring(2, 8)}.${fileExtension}`;

            const filePath =
                `talents/${fileName}`;


            const { error: uploadError } =
                await supabaseClient
                    .storage
                    .from("talent-photos")
                    .upload(
                        filePath,
                        imageFile
                    );


            if (uploadError) {

                console.error(
                    "Image upload error:",
                    uploadError
                );

                alert(
                    "Failed to upload talent image: " +
                    uploadError.message
                );

                return;
            }


            // =========================
            // GET PUBLIC IMAGE URL
            // =========================

            const { data: publicUrlData } =
                supabaseClient
                    .storage
                    .from("talent-photos")
                    .getPublicUrl(
                        filePath
                    );


            imageUrl =
                publicUrlData.publicUrl;

        }


        // =========================
        // SAVE TALENT
        // =========================

        const { error } =
            await supabaseClient
                .from("talents")
                .insert({

                    name: name,

                    category: category,

                    bio: bio,

                    image_url: imageUrl,

                    display_order:
                        Number(displayOrder) || 0,

                    is_active: true

                });


        if (error) {

            console.error(
                "Insert error:",
                error
            );

            alert(
                "Failed to add talent: " +
                error.message
            );

            return;
        }


        alert(
            "Talent added successfully!"
        );


        // =========================
        // RESET FORM
        // =========================

        document
            .getElementById("talent-name")
            .value = "";

        document
            .getElementById("talent-category")
            .value = "";

        document
            .getElementById("talent-bio")
            .value = "";

        document
            .getElementById("talent-image")
            .value = "";

        document
            .getElementById("talent-order")
            .value = "0";


        addTalentForm.style.display =
            "none";


        loadTalents();

    });


    // =========================
    // LOAD TALENTS
    // =========================

    async function loadTalents() {

        const { data, error } =
            await supabaseClient
                .from("talents")
                .select("*")
                .order(
                    "display_order",
                    {
                        ascending: true
                    }
                );


        if (error) {

            console.error(
                "Talents error:",
                error
            );

            return;
        }


        const talentsList =
            document.getElementById(
                "talents-list"
            );


        talentsList.innerHTML = "";


        data.forEach((talent) => {

            const talentItem =
                document.createElement(
                    "div"
                );


            talentItem.innerHTML = `

                <div>

                    <h3>
                        ${talent.name}
                    </h3>

                    <p>
                        <strong>
                            Category:
                        </strong>

                        ${talent.category}
                    </p>

                    <p>
                        ${talent.bio}
                    </p>

                </div>


                <div class="talent-actions">

                    <button
                        class="edit-talent"
                    >
                        Edit
                    </button>

                    <button
                        class="delete-talent"
                    >
                        Delete
                    </button>

                </div>

            `;


            talentsList.appendChild(
                talentItem
            );


            // =========================
            // EDIT TALENT
            // =========================

            const editButton =
                talentItem.querySelector(
                    ".edit-talent"
                );


            editButton.addEventListener(
                "click",
                async () => {

                    console.log(
                        "Talent ID:",
                        talent.id
                    );


                    const newName =
                        prompt(
                            "Enter new talent name:",
                            talent.name
                        );


                    if (newName === null) {
                        return;
                    }


                    const newCategory =
                        prompt(
                            "Enter new talent category:",
                            talent.category
                        );


                    if (newCategory === null) {
                        return;
                    }


                    const newBio =
                        prompt(
                            "Enter new talent bio:",
                            talent.bio
                        );


                    if (newBio === null) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("talents")
                            .update({

                                name:
                                    newName,

                                category:
                                    newCategory,

                                bio:
                                    newBio

                            })
                            .eq(
                                "id",
                                talent.id
                            );


                    if (error) {

                        console.error(
                            "Update error:",
                            error
                        );

                        alert(
                            "Failed to update talent: " +
                            error.message
                        );

                        return;
                    }


                    alert(
                        "Talent updated successfully!"
                    );


                    loadTalents();

                }
            );


            // =========================
            // DELETE TALENT
            // =========================

            const deleteButton =
                talentItem.querySelector(
                    ".delete-talent"
                );


            deleteButton.addEventListener(
                "click",
                async () => {

                    const confirmed =
                        confirm(
                            `Are you sure you want to delete "${talent.name}"?`
                        );


                    if (!confirmed) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("talents")
                            .delete()
                            .eq(
                                "id",
                                talent.id
                            );


                    if (error) {

                        console.error(
                            "Delete error:",
                            error
                        );

                        alert(
                            "Failed to delete talent: " +
                            error.message
                        );

                        return;
                    }


                    alert(
                        "Talent deleted successfully!"
                    );


                    loadTalents();

                }
            );

        });

    }


    // =========================
    // INITIAL LOAD
    // =========================

    loadTalents();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});