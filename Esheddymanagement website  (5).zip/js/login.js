document.addEventListener("DOMContentLoaded", () => {

    const loginForm =
        document.getElementById("login-form");

    const loginMessage =
        document.getElementById("login-message");

    const loginButton =
        document.getElementById("login-btn");


    loginForm.addEventListener("submit", async (event) => {

        event.preventDefault();


        const email =
            document.getElementById("login-email").value.trim();

        const password =
            document.getElementById("login-password").value;


        loginButton.disabled = true;
        loginButton.textContent = "Logging in...";

        loginMessage.textContent = "";


        const { data, error } =
            await supabaseClient.auth.signInWithPassword({
                email: email,
                password: password
            });


        if (error) {

            console.error("Login error:", error);

            loginMessage.textContent =
                "Login failed. Please check your email and password.";

            loginButton.disabled = false;
            loginButton.textContent = "Login";

            return;
        }


        console.log("Login successful:", data);


        window.location.href = "index.html";

    });

});