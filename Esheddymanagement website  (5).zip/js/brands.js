document.addEventListener("DOMContentLoaded", () => {

    const addBrandBtn =
        document.getElementById("add-brand-btn");

    const addBrandForm =
        document.getElementById("add-brand-form");

    const cancelBrandBtn =
        document.getElementById("cancel-brand-btn");

    const saveBrandBtn =
        document.getElementById("save-brand-btn");


    addBrandBtn.addEventListener("click", () => {

        addBrandForm.style.display = "block";
        addBrandBtn.style.display = "none";

    });


    cancelBrandBtn.addEventListener("click", () => {

        addBrandForm.style.display = "none";
        addBrandBtn.style.display = "block";

    });


    saveBrandBtn.addEventListener("click", async () => {

        const name =
            document.getElementById("brand-name")
                .value.trim();

        const description =
            document.getElementById("brand-description")
                .value.trim();

        const logoInput =
            document.getElementById("brand-logo");

        const logoFile =
            logoInput.files[0];

        const websiteUrl =
            document.getElementById("brand-website")
                .value.trim();

        const displayOrder =
            document.getElementById("brand-order")
                .value;


        if (!name) {

            alert(
                "Please enter the brand or organization name."
            );

            return;
        }


        let logoUrl = "";


        /*
         * Upload brand logo
         */

        if (logoFile) {

            const fileExtension =
                logoFile.name
                    .split(".")
                    .pop();

            const fileName =
                `brands/${Date.now()}-${Math.random()
                    .toString(36)
                    .substring(2)}.${fileExtension}`;


            const { error: uploadError } =
                await supabaseClient
                    .storage
                    .from("brand-logos")
                    .upload(
                        fileName,
                        logoFile
                    );


            if (uploadError) {

                console.error(
                    "Brand logo upload error:",
                    uploadError
                );

                alert(
                    "Failed to upload brand logo: " +
                    uploadError.message
                );

                return;
            }


            const { data: publicUrlData } =
                supabaseClient
                    .storage
                    .from("brand-logos")
                    .getPublicUrl(fileName);


            logoUrl =
                publicUrlData.publicUrl;

        }


        /*
         * Save brand
         */

        const { error } =
            await supabaseClient
                .from("brands")
                .insert({

                    name: name,

                    description: description,

                    logo_url: logoUrl,

                    website_url: websiteUrl,

                    is_active: true,

                    display_order:
                        Number(displayOrder) || 0

                });


        if (error) {

            console.error(
                "Insert brand error:",
                error
            );

            alert(
                "Failed to add brand: " +
                error.message
            );

            return;
        }


        alert(
            "Brand added successfully!"
        );


        document.getElementById(
            "brand-name"
        ).value = "";

        document.getElementById(
            "brand-description"
        ).value = "";

        document.getElementById(
            "brand-logo"
        ).value = "";

        document.getElementById(
            "brand-website"
        ).value = "";

        document.getElementById(
            "brand-order"
        ).value = "0";


        addBrandForm.style.display = "none";
        addBrandBtn.style.display = "block";


        loadBrands();

    });


    async function loadBrands() {

        const { data, error } =
            await supabaseClient
                .from("brands")
                .select("*")
                .order("display_order", {
                    ascending: true
                });


        if (error) {

            console.error(
                "Brands loading error:",
                error
            );

            return;
        }


        const brandsList =
            document.getElementById("brands-list");

        brandsList.innerHTML = "";


        data.forEach((brand) => {

            const brandItem =
                document.createElement("div");

            brandItem.className =
                "brand-item";


            brandItem.innerHTML = `

                <div class="brand-info">

                    <h3>
                        ${brand.name}
                    </h3>

                    <p>
                        ${brand.description || ""}
                    </p>

                    ${
                        brand.logo_url
                            ? `
                                <div class="brand-logo-preview">
                                    <img
                                        src="${brand.logo_url}"
                                        alt="${brand.name} logo"
                                    >
                                </div>
                            `
                            : ""
                    }

                    ${
                        brand.website_url
                            ? `
                                <a
                                    href="${brand.website_url}"
                                    class="brand-website"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Visit Website →
                                </a>
                            `
                            : ""
                    }

                </div>


                <div class="brand-actions">

                    <button
                        class="edit-brand"
                    >
                        Edit
                    </button>

                    <button
                        class="delete-brand"
                    >
                        Delete
                    </button>

                </div>

            `;


            brandsList.appendChild(brandItem);


            const editButton =
                brandItem.querySelector(
                    ".edit-brand"
                );


            editButton.addEventListener(
                "click",
                async () => {

                    const newName =
                        prompt(
                            "Enter brand name:",
                            brand.name
                        );

                    if (newName === null) {
                        return;
                    }


                    const newDescription =
                        prompt(
                            "Enter brand description:",
                            brand.description || ""
                        );

                    if (newDescription === null) {
                        return;
                    }


                    const newWebsite =
                        prompt(
                            "Enter website URL:",
                            brand.website_url || ""
                        );

                    if (newWebsite === null) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("brands")
                            .update({

                                name: newName,

                                description:
                                    newDescription,

                                website_url:
                                    newWebsite

                            })
                            .eq(
                                "id",
                                brand.id
                            );


                    if (error) {

                        console.error(
                            "Update brand error:",
                            error
                        );

                        alert(
                            "Failed to update brand: " +
                            error.message
                        );

                        return;
                    }


                    alert(
                        "Brand updated successfully!"
                    );


                    loadBrands();

                }
            );


            const deleteButton =
                brandItem.querySelector(
                    ".delete-brand"
                );


            deleteButton.addEventListener(
                "click",
                async () => {

                    const confirmed =
                        confirm(
                            `Are you sure you want to delete ${brand.name}?`
                        );


                    if (!confirmed) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("brands")
                            .delete()
                            .eq(
                                "id",
                                brand.id
                            );


                    if (error) {

                        console.error(
                            "Delete brand error:",
                            error
                        );

                        alert(
                            "Failed to delete brand: " +
                            error.message
                        );

                        return;
                    }


                    alert(
                        "Brand deleted successfully!"
                    );


                    loadBrands();

                }
            );

        });

    }


    loadBrands();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});