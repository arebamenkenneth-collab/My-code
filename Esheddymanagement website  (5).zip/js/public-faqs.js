async function loadPublicFaqs() {

    const { data, error } = await supabaseClient
        .from("faqs")
        .select("*")
        .eq("is_active", true)
        .order("display_order", {
            ascending: true
        });


    if (error) {

        console.error(
            "Public FAQs error:",
            error
        );

        return;

    }


    const faqsList =
        document.getElementById("public-faqs-list");


    if (!faqsList) {
        return;
    }


    faqsList.innerHTML = "";


    data.forEach((faq) => {

        const faqItem =
            document.createElement("div");

        faqItem.className = "faq-item";


        faqItem.innerHTML = `

            <button
                class="faq-question"
                type="button"
            >

                <span>
                    ${faq.question}
                </span>

                <span class="faq-icon">
                    +
                </span>

            </button>


            <div class="faq-answer">

                <p>
                    ${faq.answer}
                </p>

            </div>

        `;


        faqsList.appendChild(faqItem);


        const question =
            faqItem.querySelector(".faq-question");


        question.addEventListener("click", () => {

            faqItem.classList.toggle("active");

        });

    });

}


loadPublicFaqs();