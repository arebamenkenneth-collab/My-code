async function loadPublicSettings() {

const { data, error } = await supabaseClient
    .from("site_settings")
    .select("*")
    .eq("id", 1)
    .maybeSingle();

if (error) {
    console.error("Public settings error:", error);
    return;
}

if (!data) {
    console.warn("No site settings data found.");
    return;
}


// Email
const emailElements =
    document.querySelectorAll(".company-email");

emailElements.forEach((element) => {

    element.textContent = data.email || "";

    if (element.tagName === "A" && data.email) {
        element.href = `mailto:${data.email}`;
    }

});


// Phone
const phoneElements =
    document.querySelectorAll(".company-phone");

phoneElements.forEach((element) => {

    element.textContent = data.phone || "";

    if (element.tagName === "A" && data.phone) {
        element.href = `tel:${data.phone}`;
    }

});


// WhatsApp
const whatsappElements =
    document.querySelectorAll(".company-whatsapp");

whatsappElements.forEach((element) => {

    element.textContent = data.whatsapp || "";

    if (element.tagName === "A" && data.whatsapp) {

        const whatsappNumber =
            data.whatsapp.replace(/\D/g, "");

        element.href =
            `https://wa.me/${whatsappNumber}`;

        element.target = "_blank";
        element.rel = "noopener noreferrer";

    }

});


// Location
const locationElements =
    document.querySelectorAll(".company-location");

locationElements.forEach((element) => {

    element.textContent = data.location || "";

});


// Tagline
const taglineElements =
    document.querySelectorAll(".company-tagline");

taglineElements.forEach((element) => {

    element.textContent = data.tagline || "";

});


// Company Logo
const companyLogo =
    document.getElementById("public-company-logo");

if (companyLogo && data.logo_url) {

    companyLogo.src = data.logo_url;

}

}

document.addEventListener(
"DOMContentLoaded",
loadPublicSettings
);