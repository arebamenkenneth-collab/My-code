document.addEventListener("DOMContentLoaded", () => {

const descriptionInput =
    document.getElementById("about-description");

const missionInput =
    document.getElementById("about-mission");

const visionInput =
    document.getElementById("about-vision");

const saveButton =
    document.getElementById("save-about-btn");


async function loadAboutInformation() {

    const { data, error } =
        await supabaseClient
            .from("site_settings")
            .select(
                "description, mission, vision"
            )
            .eq("id", 1)
            .maybeSingle();


    if (error) {

        console.error(
            "About information error:",
            error
        );

        alert(
            "Failed to load About information."
        );

        return;
    }


    if (!data) {
        return;
    }


    descriptionInput.value =
        data.description || "";

    missionInput.value =
        data.mission || "";

    visionInput.value =
        data.vision || "";

}


saveButton.addEventListener(
    "click",
    async () => {

        const description =
            descriptionInput.value.trim();

        const mission =
            missionInput.value.trim();

        const vision =
            visionInput.value.trim();


        if (
            !description ||
            !mission ||
            !vision
        ) {

            alert(
                "Please complete all About information."
            );

            return;
        }


        const { error } =
            await supabaseClient
                .from("site_settings")
                .update({
                    description: description,
                    mission: mission,
                    vision: vision,
                    updated_at:
                        new Date().toISOString()
                })
                .eq("id", 1);


        if (error) {

            console.error(
                "Save About error:",
                error
            );

            alert(
                "Failed to save About information: " +
                error.message
            );

            return;
        }


        alert(
            "About information updated successfully!"
        );

    }
);


loadAboutInformation();

});

window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});