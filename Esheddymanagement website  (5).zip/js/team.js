document.addEventListener("DOMContentLoaded", () => {

    const addTeamBtn =
        document.getElementById("add-team-btn");

    const addTeamForm =
        document.getElementById("add-team-form");

    const cancelTeamBtn =
        document.getElementById("cancel-team-btn");

    const saveTeamBtn =
        document.getElementById("save-team-btn");


    // =========================
    // SHOW ADD TEAM FORM
    // =========================

    addTeamBtn.addEventListener("click", () => {

        addTeamForm.style.display = "block";

        addTeamBtn.style.display = "none";

    });


    // =========================
    // HIDE ADD TEAM FORM
    // =========================

    cancelTeamBtn.addEventListener("click", () => {

        addTeamForm.style.display = "none";

        addTeamBtn.style.display = "block";

    });


    // =========================
    // ADD TEAM MEMBER
    // =========================

    saveTeamBtn.addEventListener("click", async () => {

        const name =
            document
                .getElementById("team-name")
                .value
                .trim();

        const position =
            document
                .getElementById("team-position")
                .value
                .trim();

        const bio =
            document
                .getElementById("team-bio")
                .value
                .trim();

        const imageFile =
            document
                .getElementById("team-image")
                .files[0];

        const displayOrder =
            document
                .getElementById("team-order")
                .value;


        // =========================
        // VALIDATION
        // =========================

        if (!name || !position) {

            alert(
                "Please enter the team member's name and position."
            );

            return;

        }


        // =========================
        // IMAGE URL
        // =========================

        let imageUrl = "";


        // =========================
        // UPLOAD TEAM PHOTO
        // =========================

        if (imageFile) {

            const fileExtension =
                imageFile.name
                    .split(".")
                    .pop();

            const fileName =
                `${Date.now()}-${Math.random()
                    .toString(36)
                    .substring(2, 8)}.${fileExtension}`;

            const filePath =
                `team/${fileName}`;


            const { error: uploadError } =
                await supabaseClient
                    .storage
                    .from("team-photos")
                    .upload(
                        filePath,
                        imageFile
                    );


            if (uploadError) {

                console.error(
                    "Team image upload error:",
                    uploadError
                );

                alert(
                    "Failed to upload team image: " +
                    uploadError.message
                );

                return;

            }


            // =========================
            // GET PUBLIC IMAGE URL
            // =========================

            const { data: publicUrlData } =
                supabaseClient
                    .storage
                    .from("team-photos")
                    .getPublicUrl(
                        filePath
                    );


            imageUrl =
                publicUrlData.publicUrl;

        }


        // =========================
        // SAVE TEAM MEMBER
        // =========================

        const { error } =
            await supabaseClient
                .from("team_members")
                .insert({

                    name: name,

                    position: position,

                    bio: bio,

                    image_url: imageUrl,

                    is_active: true,

                    display_order:
                        Number(displayOrder) || 0

                });


        if (error) {

            console.error(
                "Insert team member error:",
                error
            );

            alert(
                "Failed to add team member: " +
                error.message
            );

            return;

        }


        alert(
            "Team member added successfully!"
        );


        // =========================
        // RESET FORM
        // =========================

        document.getElementById(
            "team-name"
        ).value = "";

        document.getElementById(
            "team-position"
        ).value = "";

        document.getElementById(
            "team-bio"
        ).value = "";

        document.getElementById(
            "team-image"
        ).value = "";

        document.getElementById(
            "team-order"
        ).value = "0";


        addTeamForm.style.display =
            "none";

        addTeamBtn.style.display =
            "block";


        loadTeam();

    });


    // =========================
    // LOAD TEAM
    // =========================

    async function loadTeam() {

        const { data, error } =
            await supabaseClient
                .from("team_members")
                .select("*")
                .order(
                    "display_order",
                    {
                        ascending: true
                    }
                );


        if (error) {

            console.error(
                "Team loading error:",
                error
            );

            return;

        }


        const teamList =
            document.getElementById(
                "team-list"
            );

        teamList.innerHTML = "";


        data.forEach((member) => {

            const teamItem =
                document.createElement("div");

            teamItem.className =
                "team-item";


            teamItem.innerHTML = `

                <div class="team-info">

                    <h3>
                        ${member.name}
                    </h3>

                    <div class="team-position">
                        ${member.position}
                    </div>

                    <p>
                        ${member.bio || ""}
                    </p>

                </div>


                <div class="team-actions">

                    <button
                        class="edit-team"
                    >
                        Edit
                    </button>

                    <button
                        class="delete-team"
                    >
                        Delete
                    </button>

                </div>

            `;


            teamList.appendChild(
                teamItem
            );


            // =========================
            // EDIT TEAM MEMBER
            // =========================

            const editButton =
                teamItem.querySelector(
                    ".edit-team"
                );


            editButton.addEventListener(
                "click",
                async () => {

                    const newName =
                        prompt(
                            "Enter team member name:",
                            member.name
                        );


                    if (newName === null) {
                        return;
                    }


                    const newPosition =
                        prompt(
                            "Enter position:",
                            member.position
                        );


                    if (newPosition === null) {
                        return;
                    }


                    const newBio =
                        prompt(
                            "Enter biography:",
                            member.bio || ""
                        );


                    if (newBio === null) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("team_members")
                            .update({

                                name: newName,

                                position:
                                    newPosition,

                                bio: newBio

                            })
                            .eq(
                                "id",
                                member.id
                            );


                    if (error) {

                        console.error(
                            "Update team member error:",
                            error
                        );

                        alert(
                            "Failed to update team member: " +
                            error.message
                        );

                        return;

                    }


                    alert(
                        "Team member updated successfully!"
                    );


                    loadTeam();

                }
            );


            // =========================
            // DELETE TEAM MEMBER
            // =========================

            const deleteButton =
                teamItem.querySelector(
                    ".delete-team"
                );


            deleteButton.addEventListener(
                "click",
                async () => {

                    const confirmed =
                        confirm(
                            `Are you sure you want to delete ${member.name}?`
                        );


                    if (!confirmed) {
                        return;
                    }


                    const { error } =
                        await supabaseClient
                            .from("team_members")
                            .delete()
                            .eq(
                                "id",
                                member.id
                            );


                    if (error) {

                        console.error(
                            "Delete team member error:",
                            error
                        );

                        alert(
                            "Failed to delete team member: " +
                            error.message
                        );

                        return;

                    }


                    alert(
                        "Team member deleted successfully!"
                    );


                    loadTeam();

                }
            );

        });

    }


    // =========================
    // INITIAL LOAD
    // =========================

    loadTeam();

});


window.addEventListener("load", () => {
    const startPoint = document.getElementById("admin-start");

    if (startPoint) {
        startPoint.scrollIntoView({
            behavior: "instant",
            block: "start"
        });
    }
});